<?php


namespace TBD\Bundle\RedirectBundle\Layout\WebCatalogBundle\DataProvider;


use Doctrine\Persistence\ManagerRegistry;
use Oro\Bundle\CatalogBundle\Layout\DataProvider\CategoryBreadcrumbProvider;
use Oro\Bundle\LocaleBundle\Helper\LocalizationHelper;
use Oro\Bundle\WebCatalogBundle\Entity\ContentNode;
use Oro\Bundle\WebCatalogBundle\Entity\ContentVariant;
use Oro\Bundle\WebCatalogBundle\Entity\Repository\ContentNodeRepository;
use Oro\Bundle\WebCatalogBundle\Entity\Repository\ContentVariantRepository;
use Oro\Bundle\WebCatalogBundle\Provider\RequestWebContentVariantProvider;
use Oro\Component\WebCatalog\Entity\ContentNodeAwareInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RequestStack;

class WebCatalogBreadcrumbProvider extends \Oro\Bundle\WebCatalogBundle\Layout\DataProvider\WebCatalogBreadcrumbProvider
{

    private $request;


    /**
     * @var CategoryBreadcrumbProvider
     */
    private CategoryBreadcrumbProvider $tbdCategoryBreadcrumbProvider;

    /**
     * WebCatalogBreadcrumbProvider constructor.
     * @param ManagerRegistry $doctrine
     * @param LocalizationHelper $localizationHelper
     * @param RequestStack $requestStack
     * @param RequestWebContentVariantProvider $requestWebContentVariantProvider
     * @param CategoryBreadcrumbProvider $categoryBreadcrumbProvider
     */
    public function __construct(ManagerRegistry $doctrine,
                                LocalizationHelper $localizationHelper,
                                RequestStack $requestStack,
                                RequestWebContentVariantProvider $requestWebContentVariantProvider,
                                CategoryBreadcrumbProvider $categoryBreadcrumbProvider)
    {
        parent::__construct($doctrine, $localizationHelper, $requestStack, $requestWebContentVariantProvider, $categoryBreadcrumbProvider);

        $this->request = $requestStack->getCurrentRequest();
        $this->tbdCategoryBreadcrumbProvider = $categoryBreadcrumbProvider;
    }

    public function getItems()
    {
        $categoryId = $this->request->attributes->get('categoryId');
        if($categoryId) {
            return $this->tbdCategoryBreadcrumbProvider->getItems();
        }

        return parent::getItems();
    }

}