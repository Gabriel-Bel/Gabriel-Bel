<?php


namespace TBD\Bundle\RedirectBundle\Layout\SEOBundle\DataProvider;


use Oro\Bundle\ConfigBundle\Config\ConfigManager;
use Oro\Bundle\FrontendLocalizationBundle\Manager\UserLocalizationManagerInterface;
use Oro\Bundle\RedirectBundle\Entity\Slug;
use Oro\Bundle\RedirectBundle\Entity\SlugAwareInterface;
use Oro\Bundle\RedirectBundle\Entity\SluggableInterface;
use Oro\Bundle\RedirectBundle\Generator\CanonicalUrlGenerator;
use Oro\Bundle\SEOBundle\Model\DTO\AlternateUrl;
use Symfony\Component\Validator\Validator\ValidatorInterface;
use Symfony\Component\Validator\Constraints\Locale;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\HttpFoundation\Request;



class LocalizedLinksDataProvider extends \Oro\Bundle\SEOBundle\Layout\DataProvider\LocalizedLinksDataProvider
{
    const USED_SLUG_KEY = '_used_slug';

    /**
     * @var CanonicalUrlGenerator
     */
    private $urlGenerator;

    /**
     * @var ConfigManager
     */
    private $configManager;


    /**
     * @var ValidatorInterface
     */
    private $validator;

    /**
     * @var UserLocalizationManagerInterface
     */
    private $userLocalizationManager;
    /**
     * @var ManagerRegistry
     */
    private ManagerRegistry $registry;
    /**
     * @var Request|null
     */
    private Request $request;


    /**
     * @param CanonicalUrlGenerator $urlGenerator
     * @param ConfigManager $configManager
     * @param UserLocalizationManagerInterface $userLocalizationManager
     * @param ValidatorInterface $validator
     */
    public function __construct(
        CanonicalUrlGenerator $urlGenerator,
        ConfigManager $configManager,
        UserLocalizationManagerInterface $userLocalizationManager,
        ValidatorInterface $validator,
        ManagerRegistry $registry,
        RequestStack $requestStack
    ) {
        $this->urlGenerator = $urlGenerator;
        $this->configManager = $configManager;
        $this->userLocalizationManager = $userLocalizationManager;

        $this->validator = $validator;

        parent::__construct($urlGenerator, $configManager, $userLocalizationManager, $validator);
        $this->registry = $registry;

        $this->request = $requestStack->getCurrentRequest();

    }


    public function getCanonicalForRoot()
    {
        if ($this->request && $this->request->attributes->has(self::USED_SLUG_KEY)) {
            $slug = $this->request->attributes->get(self::USED_SLUG_KEY);

            if($this->userLocalizationManager->getCurrentLocalization()->getId() != $this->userLocalizationManager->getDefaultLocalization()->getId()) {
                //TODO: Use language code
                return $this->urlGenerator->getAbsoluteUrl(
                    '/fr'
                );
            }
        }
        return $this->urlGenerator->getCanonicalDomainUrl();
    }

    public function getAlternatesForRoot()
    {
        $alternateUrls = [];
        $enabledLocalizations = $this->userLocalizationManager->getEnabledLocalizations();
        
        if ($this->request && $this->request->attributes->has(self::USED_SLUG_KEY)) {
            /** @var \Oro\Bundle\RedirectBundle\Entity\Slug $slug */
            $slug = $this->request->attributes->get(self::USED_SLUG_KEY);
            $this->registry->getManagerForClass(Slug::class)->refresh($slug);

            foreach ($enabledLocalizations as $localization) {

                if($localization->getId() == $this->userLocalizationManager->getDefaultLocalization()->getId()) {
                    $alternateUrlString = $this->urlGenerator->getCanonicalDomainUrl();
                    $alternateUrls[] = new AlternateUrl(
                        $alternateUrlString,
                        $localization
                    );
                    $alternateUrls[] = new AlternateUrl(
                        $alternateUrlString,
                        null
                    );
                } else {
                    //On a déja vu mieux, mais on fait avec ce qu'on a
                    //TODO: A mutualiser pour le /fr plus haut
                    $alternateUrlString = $alternateUrlString = $this->urlGenerator->getAbsoluteUrl('/' . preg_replace('/_\w+$/', '', $localization->getFormattingCode()));
                    $alternateUrls[] = new AlternateUrl(
                        $alternateUrlString,
                        $localization
                    );
                }
            }

        }

        return $alternateUrls;
    }
    
    
    
    

    /**
     * @param SlugAwareInterface|SluggableInterface $data
     * @return array|AlternateUrl[]
     */
    public function getAlternates(SlugAwareInterface $data)
    {
        $localizationMap = $this->getApplicableLocalizationsMap();
        $result = [];
        if (!$localizationMap) {
            return $result;
        }

        $result = $this->getAlternateUrlsBasedOnSlugs($data, $localizationMap);

        return $result;
    }


    /**
     * @return array
     */
    private function getApplicableLocalizationsMap()
    {
        $enabledLocalizations = $this->userLocalizationManager->getEnabledLocalizations();

        if (count($enabledLocalizations) <= 1) {
            return [];
        }

        $localizations = [];
        foreach ($enabledLocalizations as $localization) {
            $locale = new Locale(['canonicalize' => true]);
            if (!$this->validator->validate($localization->getLanguageCode(), $locale)->count()) {
                $localizations[$localization->getId()] = $localization;
            }
        }

        return $localizations;
    }


    private function getAlternateUrlsBasedOnSlugs(SlugAwareInterface $data, array $localizations)
    {
        $alternateUrls = [];

        $defaultLocalization = $this->userLocalizationManager->getDefaultLocalization();

        $currentLocalization = $this->userLocalizationManager->getCurrentLocalization();

        if( $currentLocalization
            && $currentLocalization->getId() == $defaultLocalization->getId()
            && !empty($localizations[$currentLocalization->getId()])
        ) {
            unset($localizations[$currentLocalization->getId()]);
        }

        foreach ($data->getSlugs() as $slug) {
            $this->registry->getManagerForClass(Slug::class)->refresh($slug);
            $localization = $slug->getLocalization();

            if ($localization && empty($localizations[$localization->getId()])) {
                continue;
            }


            $alternateUrlString = $this->urlGenerator->getDirectUrl($data, $localization);
            $alternateUrls[] = new AlternateUrl(
                $alternateUrlString,
                $localization
            );

            //Ajout de l'URL courante dans les alternate avec la localization (different de x-deafult)
            if(empty($localization)) {
                $alternateUrls[] = new AlternateUrl(
                    $alternateUrlString,
                    $defaultLocalization
                );
            }

        }
        return $alternateUrls;
    }

}