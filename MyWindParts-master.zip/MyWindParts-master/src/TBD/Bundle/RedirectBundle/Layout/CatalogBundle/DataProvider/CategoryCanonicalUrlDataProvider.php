<?php

namespace TBD\Bundle\RedirectBundle\Layout\CatalogBundle\DataProvider;


use Oro\Bundle\CatalogBundle\Entity\Category;
use Oro\Bundle\CatalogBundle\Provider\CategoryRoutingInformationProvider;
use Oro\Bundle\ConfigBundle\Config\ConfigManager;
use Oro\Bundle\FrontendLocalizationBundle\Manager\UserLocalizationManager;
use Oro\Bundle\RedirectBundle\Generator\CanonicalUrlGenerator;
use Oro\Bundle\WebCatalogBundle\Provider\ContentNodeProvider;
use Oro\Bundle\WebsiteBundle\Resolver\WebsiteUrlResolver;
use TBD\Bundle\RedirectBundle\Helper\RedirectLocalizationHelper;

/**
 * Short canonical for category
 *
 * Class CategoryCanonicalUrlDataProvider
 * @package TBD\Bundle\RedirectBundle\Layout\CatalogBundle\DataProvider
 */
class CategoryCanonicalUrlDataProvider extends \Oro\Bundle\CatalogBundle\Layout\DataProvider\CategoryCanonicalUrlDataProvider
{


    /**
     * @var RedirectLocalizationHelper
     */
    private RedirectLocalizationHelper $redirectLocalizationHelper;

    public function __construct(ConfigManager $configManager,
                                WebsiteUrlResolver $websiteSystemUrlResolver,
                                ContentNodeProvider $contentNodeProvider,
                                CanonicalUrlGenerator $canonicalUrlGenerator,
                                CategoryRoutingInformationProvider $routingInformationProvider,
                                RedirectLocalizationHelper $redirectLocalizationHelper)
    {
        parent::__construct($configManager, $websiteSystemUrlResolver, $contentNodeProvider, $canonicalUrlGenerator, $routingInformationProvider);

        $this->redirectLocalizationHelper = $redirectLocalizationHelper;
    }

    /**
     * @param Category $category
     * @param bool $includeSubcategories
     * @return string
     */
    public function getUrl(Category $category, bool $includeSubcategories = false)
    {
        $url = $this->redirectLocalizationHelper->getDirectLocalizedUrl($category);
        return $url ? $url : parent::getUrl($category, false);
    }
}