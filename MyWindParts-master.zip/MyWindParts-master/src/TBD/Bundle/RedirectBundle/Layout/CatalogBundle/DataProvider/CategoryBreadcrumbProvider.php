<?php


namespace TBD\Bundle\RedirectBundle\Layout\CatalogBundle\DataProvider;


class CategoryBreadcrumbProvider extends \Oro\Bundle\CatalogBundle\Layout\DataProvider\CategoryBreadcrumbProvider
{
    public function getItems()
    {
        $breadcrumbs = parent::getItems();
        if(!empty($breadcrumbs) && is_array($breadcrumbs)) {
            if(strpos($breadcrumbs[0]['url'], 'product') !==false) {
                unset($breadcrumbs[0]);
            }
        }

        return $breadcrumbs;
    }
}