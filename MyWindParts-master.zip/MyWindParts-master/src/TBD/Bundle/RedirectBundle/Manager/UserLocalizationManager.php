<?php


namespace TBD\Bundle\RedirectBundle\Manager;


use Doctrine\Persistence\ManagerRegistry;
use Oro\Bundle\ConfigBundle\Config\ConfigManager;
use Oro\Bundle\CustomerBundle\Entity\CustomerUser;
use Oro\Bundle\LocaleBundle\Entity\Localization;
use Oro\Bundle\LocaleBundle\Manager\LocalizationManager;
use Oro\Bundle\RedirectBundle\Entity\Repository\SlugRepository;
use Oro\Bundle\RedirectBundle\Entity\Slug;
use Oro\Bundle\WebsiteBundle\Entity\Website;
use Oro\Bundle\WebsiteBundle\Manager\WebsiteManager;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;
use Symfony\Component\HttpFoundation\RequestStack;



class UserLocalizationManager extends \Oro\Bundle\FrontendLocalizationBundle\Manager\UserLocalizationManager
{

    /**
     * @var RequestStack
     */
    private RequestStack $requestStack;
    /**
     * @var ManagerRegistry
     */
    private ManagerRegistry $registry;

    public function __construct(Session $session,
                                TokenStorageInterface $tokenStorage,
                                ManagerRegistry $doctrine,
                                ConfigManager $configManager,
                                WebsiteManager $websiteManager,
                                LocalizationManager $localizationManager,
                                RequestStack $requestStack
    )
    {
        parent::__construct($session, $tokenStorage, $doctrine, $configManager, $websiteManager, $localizationManager);
        $this->requestStack = $requestStack;
    }


    /** @var array */
    private $tbdCurrentLocalizations = [];

    public function getCurrentLocalization(Website $website = null): ?Localization
    {
        //return parent::getCurrentLocalization($website);

        $website = $this->getWebsite($website);
        if (!$website) {
            return null;
        }

        $user = $this->getLoggedUser();

        $websiteId = $website->getId();
        $userId = $user instanceof CustomerUser ? $user->getId() : 0;
        if (isset($this->tbdCurrentLocalizations[$websiteId][$userId])) {
            return $this->tbdCurrentLocalizations[$websiteId][$userId];
        }

        $localizationBySession = $this->session->get(self::SESSION_LOCALIZATIONS);
        if ( $userId || $localizationBySession) {
            return parent::getCurrentLocalization($website);
        }

        //Need to check if we are on the good localization
        $request = $this->requestStack->getCurrentRequest();
        $usedSlug = $request->attributes->get('_used_slug');
        //If _used_slug is already set it is to late
        if(!$usedSlug) {
            $qb = $this->getSlugRepository()->getSlugByUrlQueryBuilder($request->getPathInfo());
            $result = $qb->getQuery()->getResult();
            /** @var Slug $slug */
            if($result && $slug = current($result)) {
                if($slug->getLocalization() && $slug->getLocalization()->getId()) {

                    //Set localization based on slug localisation without redirect
                    $this->setCurrentLocalization($slug->getLocalization(), null, true);

                    $this->tbdCurrentLocalizations[$websiteId][$userId] = $slug->getLocalization();
                    return $slug->getLocalization();
                }
            }
        }

        return parent::getCurrentLocalization($website);
    }

    /**
     * @return SlugRepository
     */
    private function getSlugRepository(): SlugRepository
    {
        return $this->doctrine->getManagerForClass(Slug::class)
            ->getRepository(Slug::class);
    }
}