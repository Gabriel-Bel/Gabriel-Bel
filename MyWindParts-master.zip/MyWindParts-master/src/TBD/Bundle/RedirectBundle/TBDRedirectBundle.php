<?php

namespace TBD\Bundle\RedirectBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TBDRedirectBundle extends Bundle
{
}

