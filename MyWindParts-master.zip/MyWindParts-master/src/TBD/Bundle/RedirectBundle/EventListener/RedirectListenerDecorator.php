<?php

namespace TBD\Bundle\RedirectBundle\EventListener;

use Doctrine\Persistence\ManagerRegistry;
use Oro\Bundle\FrontendLocalizationBundle\Manager\UserLocalizationManager;
use Oro\Bundle\RedirectBundle\Entity\Slug;
use Oro\Bundle\RedirectBundle\Generator\CanonicalUrlGenerator;
use Oro\Bundle\RedirectBundle\Provider\SlugSourceEntityProviderInterface;
use Oro\Bundle\WebsiteBundle\Manager\WebsiteManager;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use TBD\Bundle\RedirectBundle\Helper\RedirectLocalizationHelper;
use Symfony\Component\HttpFoundation\Request;


/**
 *
 * Redirect listener for the slug with current localization
 */
class RedirectListenerDecorator
{

    const TBD_REDIRECT_PARAM = 'localization_redirect';

    /**
     * @var UserLocalizationManager
     */
    protected $userLocalizationManager;

    /**
     * @var SlugSourceEntityProviderInterface
     */
    protected $slugSourceEntityProvider;

    /**
     * @var ManagerRegistry
     */
    protected $registry;

    /**
     * @var CanonicalUrlGenerator
     */
    protected $canonicalUrlGenerator;

    /**
     * @var WebsiteManager
     */
    protected $websiteManager;
    /**
     * @var UserLocalizationManager
     */
    private $localizationManager;
    /**
     * @var \TBD\Bundle\RedirectBundle\Helper\RedirectLocalizationHelper
     */
    private $tbdRedictionHelper;
    private $tbd_new_localization;

    /**
     * @param UserLocalizationManager $userLocalizationManager
     * @param SlugSourceEntityProviderInterface $slugSourceEntityProvider
     * @param ManagerRegistry $registry
     * @param CanonicalUrlGenerator $canonicalUrlGenerator
     * @param WebsiteManager $websiteManager
     * @param UserLocalizationManager $localizationManager
     * @param \TBD\Bundle\RedirectBundle\Helper\RedirectLocalizationHelper $tbdRedictionHelper
     */
    public function __construct(
        UserLocalizationManager $userLocalizationManager,
        SlugSourceEntityProviderInterface $slugSourceEntityProvider,
        ManagerRegistry $registry,
        CanonicalUrlGenerator $canonicalUrlGenerator,
        WebsiteManager $websiteManager,
        UserLocalizationManager $localizationManager,
        RedirectLocalizationHelper $tbdRedictionHelper
    ) {
        $this->userLocalizationManager = $userLocalizationManager;
        $this->slugSourceEntityProvider = $slugSourceEntityProvider;
        $this->registry = $registry;
        $this->canonicalUrlGenerator = $canonicalUrlGenerator;
        $this->websiteManager = $websiteManager;
        $this->localizationManager = $localizationManager;
        $this->tbdRedictionHelper = $tbdRedictionHelper;
    }

    /**
     * @deprected
     * @see : \TBD\Bundle\RedirectBundle\Manager\UserLocalizationManager
     *
     * $this->setCurrentLocalization($slug->getLocalization(), null, true);
     *
     * No more used
     *
     * @param RequestEvent $event
     */
    public function onRequest(RequestEvent $event)
    {

        /**
         * @see : \TBD\Bundle\RedirectBundle\Manager\UserLocalizationManager
         *
         * $this->setCurrentLocalization($slug->getLocalization(), null, true);
         *
         */
        $disable = true;
        if ($disable) {
            return;
        }


        if($tbdNewLocalization = $this->getTbdNewLocalization($event->getRequest())) {

            $this->localizationManager->setCurrentLocalization($tbdNewLocalization, null, true);
            $url = $event->getRequest()->getUri();
            //$url .= $this->tbdRedictionHelper::TBD_REDIRECT_PARAM. '=1';
            $event->setResponse(new RedirectResponse($url));
            return;
        }

        $request = $event->getRequest();
        if (!$request->attributes->has('_used_slug')) {
            return;
        }

        $localization = $this->userLocalizationManager->getCurrentLocalization();
        if (!$localization) {
            return;
        }

        $usedSlug = $request->attributes->get('_used_slug');
        $this->registry->getManagerForClass(Slug::class)->refresh($usedSlug);
        if ($usedSlug->getLocalization() === $localization) {
            return;
        }

        $sourceEntity = $this->slugSourceEntityProvider->getSourceEntityBySlug($usedSlug);
        if (!$sourceEntity) {
            return;
        }

        $filteredCollection = $sourceEntity->getSlugs()->filter(function (Slug $element) use ($localization) {
            return $element->getLocalization() === $localization;
        });

        if ($filteredCollection->count()) {
            $localizedSlug = $filteredCollection->first();

        } else {
            $localizedSlug = $sourceEntity->getSlugs()->filter(function (Slug $element) {
                return !$element->getLocalization();
            })->first();
        }

        // We can't compare entities because in some cases they can be different objects.
        if ($localizedSlug && $localizedSlug->getUrl() !== $usedSlug->getUrl()) {

            $url = $this->canonicalUrlGenerator->getAbsoluteUrl(
                $localizedSlug->getUrl(),
                $this->websiteManager->getCurrentWebsite()
            );
            $event->setResponse(new RedirectResponse($url));
            return;
        }
    }



    public function getTbdNewLocalization($request)
    {

        if(is_null($this->tbd_new_localization)) {
            $this->tbd_new_localization = $this->getNewLocalization($request);
        }

        return $this->tbd_new_localization;
    }


    protected function getNewLocalization(Request $request)
    {
        if ($request->query->has(self::TBD_REDIRECT_PARAM)) {
            return false;
        }

        if (!$request->attributes->has('_used_slug')) {
            return false;
        }

        $localization = $this->userLocalizationManager->getCurrentLocalization();
        if (!$localization) {
            return false;
        }
        $usedSlug = $request->attributes->get('_used_slug');
        $this->registry->getManagerForClass(Slug::class)->refresh($usedSlug);
        if ($usedSlug->getLocalization() === $localization) {
            return false;
        }

        $sourceEntity = $this->slugSourceEntityProvider->getSourceEntityBySlug($usedSlug);
        if (!$sourceEntity) {
            return false;
        }

        $filteredCollection = $sourceEntity->getSlugs()->filter(function (Slug $element) use ($localization) {
            return $element->getLocalization() === $localization;
        });

        if ($filteredCollection->count()) {
            $localizedSlug = $filteredCollection->first();

        } else {
            $localizedSlug = $sourceEntity->getSlugs()->filter(function (Slug $element) {
                return !$element->getLocalization();
            })->first();
        }

        // We can't compare entities because in some cases they can be different objects.
        if ($localizedSlug && $localizedSlug->getUrl() !== $usedSlug->getUrl()) {

            $newLocalization = $usedSlug->getLocalization() ? $usedSlug->getLocalization() : $this->localizationManager->getDefaultLocalization();

            $externalReferer = false;
            //TODO: Attention au nom du site
            $currentHost = $request->server->get('HTTP_HOST');

            if(!$request->server->has('HTTP_REFERER') || strpos($request->server->get('HTTP_REFERER'), $currentHost)===false) {
                $externalReferer = true;
            }

            if ($externalReferer && $newLocalization && array_key_exists($newLocalization->getId(), $this->localizationManager->getEnabledLocalizations())) {
                return $newLocalization;
            }
            return false;
        }
    }
}