<?php


namespace TBD\Bundle\RedirectBundle\EventListener;


use Doctrine\ORM\Event\LoadClassMetadataEventArgs;
use Doctrine\ORM\Mapping\ClassMetadataInfo;

class ClassMetadataListener
{
    /**
     * Run when Doctrine ORM metadata is loaded.
     * Processes event and attach the entity listener.
     * Read annotations
     *
     * Called when cache is flushed
     *
     * @param LoadClassMetadataEventArgs $eventArgs
     */
    public function loadClassMetadata(LoadClassMetadataEventArgs $event)
    {
        /** @var ClassMetadataInfo $classMetadata */
        $classMetadata = $event->getClassMetadata();

        if ('Oro\Bundle\WebCatalogBundle\Entity\ContentVariant' === $classMetadata->name) {
            $classMetadata->customRepositoryClassName = 'TBD\Bundle\RedirectBundle\Entity\Repository\ContentVariantRepository';
        }
    }
}