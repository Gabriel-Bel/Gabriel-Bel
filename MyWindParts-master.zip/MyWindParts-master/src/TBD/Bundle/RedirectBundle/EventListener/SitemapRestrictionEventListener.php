<?php


namespace TBD\Bundle\RedirectBundle\EventListener;


use Oro\Bundle\SEOBundle\Event\RestrictSitemapEntitiesEvent;

class SitemapRestrictionEventListener
{

    /**
     * No more used (commented in services.yml)
     * Method to adapt query scope for sitempa generation
     *
     * @param RestrictSitemapEntitiesEvent $event
     */
    public function restrictQueryBuilder(RestrictSitemapEntitiesEvent $event) {
        $queryBuilder = $event->getQueryBuilder();
        $queryBuilder->andWhere($queryBuilder->expr()->isNull('slugs.localization'));
   }
}