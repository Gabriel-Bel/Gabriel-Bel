<?php


namespace TBD\Bundle\RedirectBundle\Helper;

use Oro\Bundle\FrontendLocalizationBundle\Manager\UserLocalizationManager;
use Oro\Bundle\RedirectBundle\Entity\SluggableInterface;
use Oro\Bundle\RedirectBundle\Generator\CanonicalUrlGenerator;

class RedirectLocalizationHelper
{
    /**
     * @var UserLocalizationManager
     */
    protected $userLocalizationManager;

    /**
     * @var CanonicalUrlGenerator
     */
    protected $canonicalUrlGenerator;


    /**
     * RedirectLocalizationHelper constructor.
     * @param UserLocalizationManager $userLocalizationManager
     * @param CanonicalUrlGenerator $canonicalUrlGenerator
     */
    public function __construct(
        UserLocalizationManager $userLocalizationManager,
        CanonicalUrlGenerator $canonicalUrlGenerator
    ) {
        $this->userLocalizationManager = $userLocalizationManager;
        $this->canonicalUrlGenerator = $canonicalUrlGenerator;
    }

    /**
     * @param SluggableInterface $data
     * @return string
     */
    public function getDirectLocalizedUrl(SluggableInterface $data)
    {
        $localization = $this->userLocalizationManager->getCurrentLocalization();
        $defaultLocalization = $this->userLocalizationManager->getDefaultLocalization();
        if ($localization && $localization->getId() != $defaultLocalization->getId()) {
            $url = $this->canonicalUrlGenerator->getDirectUrl($data, $localization);
        } else {
            $url = $this->canonicalUrlGenerator->getDirectUrl($data);
        }

        return $url;
    }

}