<?php


namespace TBD\Bundle\RedirectBundle\Entity\Repository;


use Oro\Bundle\RedirectBundle\Entity\Slug;
use Oro\Bundle\WebCatalogBundle\Entity\ContentVariant;

class ContentVariantRepository extends \Oro\Bundle\WebCatalogBundle\Entity\Repository\ContentVariantRepository
{
    /**
     * @param Slug $slug
     * @return ContentVariant
     */
    public function findVariantBySlug(Slug $slug)
    {
        $variantsBySlug = parent::findVariantBySlug($slug);

        // If there is no variant we supposed to be on a canonical URl
        // so we have to found the slug from web catalog to construct full breadcrumb
        if(!$variantsBySlug) {
            $routeParameters = $slug->getRouteParameters();
            if(!empty($routeParameters['categoryId']) && !isset($routeParameters['overrideVariantConfiguration'])) {
                $routeParameters = $slug->getRouteParameters();
                if(!empty($routeParameters['categoryId']) && !isset($routeParameters['overrideVariantConfiguration'])) {
                    $localization = $slug->getLocalization() ? $slug->getLocalization()->getId() : null;
                    $qbTbd = $this->getEntityManager()->createQueryBuilder();
                    $qbTbd->select('variant', 'slugs')
                        ->from(\Oro\Bundle\WebCatalogBundle\Entity\ContentVariant::class, 'variant')
                        ->join('variant.slugs', 'slugs')
                        ->where($qbTbd->expr()->eq('variant.category_page_category', $routeParameters['categoryId']));
                    if($localization) {
                        $qbTbd->andWhere($qbTbd->expr()->eq('slugs.localization', $localization));
                    } else {
                        $qbTbd->andWhere($qbTbd->expr()->isNull('slugs.localization'));
                    }

                    $variantsByFullPathSlug = $qbTbd->getQuery()->getOneOrNullResult();
                    if($variantsByFullPathSlug && $variantsByFullPathSlug->getId()) {
                        return $variantsByFullPathSlug;
                    }
                }
            }
        }

        return $variantsBySlug;
    }
}