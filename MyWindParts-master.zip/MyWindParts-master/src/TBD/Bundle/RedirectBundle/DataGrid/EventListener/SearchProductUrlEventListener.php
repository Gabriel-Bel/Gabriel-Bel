<?php


namespace TBD\Bundle\RedirectBundle\DataGrid\EventListener;


use Oro\Bundle\DataGridBundle\Datasource\ResultRecord;
use Oro\Bundle\DataGridBundle\Event\OrmResultAfter;
use Oro\Bundle\DataGridBundle\Event\PreBuild;
use Oro\Bundle\DataGridBundle\Extension\Formatter\Property\PropertyInterface;
use Oro\Bundle\EntityBundle\ORM\DoctrineHelper;
use Oro\Bundle\FrontendLocalizationBundle\Manager\UserLocalizationManager;
use Oro\Bundle\InventoryBundle\Provider\UpcomingProductProvider;
use Oro\Bundle\ProductBundle\Entity\Product;
use Oro\Bundle\ProductBundle\Entity\Repository\ProductRepository;
use Oro\Bundle\RedirectBundle\Entity\SluggableInterface;
use Oro\Bundle\RedirectBundle\Generator\CanonicalUrlGenerator;
use Oro\Bundle\SearchBundle\Datagrid\Event\SearchResultAfter;
use TBD\Bundle\RedirectBundle\Helper\RedirectLocalizationHelper;

class SearchProductUrlEventListener
{
    const TBD_REDIRECT_URL = 'tbd_url';
    /**
     * @var DoctrineHelper
     */
    private DoctrineHelper $doctrineHelper;
    /**
     * @var RedirectLocalizationHelper
     */
    private RedirectLocalizationHelper $redirectLocalizationHelper;


    /**
     * @param UpcomingProductProvider $productUpcomingProvider
     * @param DoctrineHelper $doctrineHelper
     */
    public function __construct(
        DoctrineHelper $doctrineHelper,
        RedirectLocalizationHelper $redirectLocalizationHelper

    ) {
        $this->doctrineHelper = $doctrineHelper;
        $this->redirectLocalizationHelper = $redirectLocalizationHelper;
    }


    /**
     * @param PreBuild $event
     */
    public function onPreBuild(PreBuild $event)
    {
        $config = $event->getConfig();
        $config->offsetAddToArrayByPath(
            '[properties]',
            [
                self::TBD_REDIRECT_URL => [
                    'type' => 'field',
                    'frontend_type' => PropertyInterface::TYPE_STRING,
                ],
            ]
        );
    }

    /**
     * @param OrmResultAfter $event
     */
    public function onResultAfter(SearchResultAfter $event)
    {
        $records = $event->getRecords();
        $tbdRedirectUrlProductsData = $this->prepareDataForTbdRedirectUrlCollection($records);

        foreach ($records as $record) {
            $productId = $record->getValue('id');
            $record->addData($tbdRedirectUrlProductsData[$productId]);

        }
    }


    /**
     * @param ResultRecord[] $records
     *
     * @return Product[]
     */
    protected function prepareDataForTbdRedirectUrlCollection(array $records)
    {
        $data = [];
        $products = $this->getProductsEntities($records);

        foreach ($products as $product) {
                $data[$product->getId()] = [
                    self::TBD_REDIRECT_URL => $this->redirectLocalizationHelper->getDirectLocalizedUrl($product)
                ];
        }
        return $data;
    }

    /**
     * @param ResultRecord[] $records
     *
     * @return Product[]
     */
    protected function getProductsEntities(array $records)
    {
        $products = [];

        /** @var ResultRecord[] $records */
        foreach ($records as $record) {
            $products[] = $record->getValue('id');
        }

        /** @var ProductRepository $productRepository */
        $productRepository = $this->doctrineHelper->getEntityRepositoryForClass(Product::class);

        return $productRepository->findBy(['id' => $products]);
    }
}