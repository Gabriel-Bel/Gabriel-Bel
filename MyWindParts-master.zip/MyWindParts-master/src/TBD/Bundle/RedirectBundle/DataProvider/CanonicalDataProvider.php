<?php


namespace TBD\Bundle\RedirectBundle\DataProvider;


use Oro\Bundle\FrontendLocalizationBundle\Manager\UserLocalizationManager;
use Oro\Bundle\RedirectBundle\Entity\SluggableInterface;
use Oro\Bundle\RedirectBundle\Generator\CanonicalUrlGenerator;


/**
 * Short canonical for product
 *
 * Class CanonicalDataProvider
 * @package TBD\Bundle\RedirectBundle\DataProvider
 */
class CanonicalDataProvider extends \Oro\Bundle\RedirectBundle\DataProvider\CanonicalDataProvider
{
    /**
     * @var UserLocalizationManager
     */
    private UserLocalizationManager $userLocalizationManager;

    public function __construct(CanonicalUrlGenerator $canonicalUrlGenerator,
                                UserLocalizationManager $userLocalizationManager)
    {
        parent::__construct($canonicalUrlGenerator);
        $this->userLocalizationManager = $userLocalizationManager;
    }

    /**
     * @param SluggableInterface $data
     * @return string
     */
    public function getUrl(SluggableInterface $data)
    {
        $url = false;
        $localization = $this->userLocalizationManager->getCurrentLocalization();
        if ($localization) {
            $url = $this->canonicalUrlGenerator->getDirectUrl($data, $localization);
        }
        return $url ? $url : parent::getUrl($data);
    }
}