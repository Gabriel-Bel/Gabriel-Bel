<?php


namespace TBD\Bundle\RedirectBundle\Sitemap\Provider;


use Doctrine\Persistence\ManagerRegistry;
use Oro\Bundle\RedirectBundle\Generator\CanonicalUrlGenerator;
use Oro\Bundle\SEOBundle\Model\DTO\UrlItem;
use Oro\Bundle\SEOBundle\Sitemap\Provider\WebCatalogScopeCriteriaProvider;
use Oro\Bundle\WebCatalogBundle\Cache\ResolvedData\ResolvedContentNode;
use Oro\Bundle\WebCatalogBundle\ContentNodeUtils\ContentNodeTreeResolverInterface;
use Oro\Bundle\WebCatalogBundle\Entity\ContentNode;
use Oro\Bundle\WebCatalogBundle\Provider\WebCatalogProvider;
use Oro\Component\Website\WebsiteInterface;

class ContentVariantUrlItemsProvider extends \Oro\Bundle\SEOBundle\Sitemap\Provider\ContentVariantUrlItemsProvider
{
    /**
     * @var ManagerRegistry
     */
    private $registry;

    /**
     * @var WebCatalogProvider
     */
    private $webCatalogProvider;

    /**
     * @var ContentNodeTreeResolverInterface
     */
    private $contentNodeTreeResolver;

    /**
     * @var CanonicalUrlGenerator
     */
    private $canonicalUrlGenerator;

    /**
     * @var WebCatalogScopeCriteriaProvider
     */
    private $scopeCriteriaProvider;

    /**
     * @param ManagerRegistry $registry
     * @param WebCatalogProvider $webCatalogProvider
     * @param ContentNodeTreeResolverInterface $contentNodeTreeResolver
     * @param CanonicalUrlGenerator $canonicalUrlGenerator
     * @param WebCatalogScopeCriteriaProvider $scopeCriteriaProvider
     */
    public function __construct(
        ManagerRegistry $registry,
        WebCatalogProvider $webCatalogProvider,
        ContentNodeTreeResolverInterface $contentNodeTreeResolver,
        CanonicalUrlGenerator $canonicalUrlGenerator,
        WebCatalogScopeCriteriaProvider $scopeCriteriaProvider
    ) {
        $this->registry = $registry;
        $this->webCatalogProvider = $webCatalogProvider;
        $this->contentNodeTreeResolver = $contentNodeTreeResolver;
        $this->canonicalUrlGenerator = $canonicalUrlGenerator;
        $this->scopeCriteriaProvider = $scopeCriteriaProvider;
    }

    public function getUrlItems(WebsiteInterface $website, $version)
    {
//        // If master catalog is enabled - we do not return catalog nodes
//        if ($this->isFeaturesEnabled($website)) {
//            return;
//        }
//
//        $webCatalog = $this->webCatalogProvider->getWebCatalog($website);
//        if (!$webCatalog) {
//            return;
//        }
//
//        $rootNode = $this->getContentNodeRepository()->getRootNodeByWebCatalog($webCatalog);
//        if (!$rootNode) {
//            return;
//        }

        $qbTbdCategory = $this->registry
            ->getManagerForClass(\Oro\Bundle\CatalogBundle\Entity\Category::class)
            ->getRepository(\Oro\Bundle\CatalogBundle\Entity\Category::class);


        /** @var \Doctrine\ORM\QueryBuilder $qbTbd */
        $qbTbd = $this->registry
            ->getManagerForClass(\Oro\Bundle\RedirectBundle\Entity\Slug::class)
            ->getRepository(\Oro\Bundle\RedirectBundle\Entity\Slug::class)
            ->createQueryBuilder('slug');


        //$qbTbd->where($qbTbd->expr()->isNull("slug.localization"));


        /** @var  \Oro\Bundle\RedirectBundle\Entity\Slug $item */
        foreach ($qbTbd->getQuery()->getResult() as $item) {
            if($item->getRouteName()=='oro_product_frontend_product_index' and
                count(explode('/', $item->getUrl()))==2
            ) {
                //TODO: Better to have directly a list of category to avoid this hack
                if($qbTbdCategory->findOneBySlug($item)) {
                    $absoluteUrl = $this->canonicalUrlGenerator->getAbsoluteUrl($item->getUrl(), $website);
                    yield new UrlItem($absoluteUrl);
                }
            }
        }
    }
}