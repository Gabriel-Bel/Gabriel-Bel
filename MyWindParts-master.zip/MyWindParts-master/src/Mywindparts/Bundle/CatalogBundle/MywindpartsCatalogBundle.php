<?php
/*
 * Copyright (c) 2014 - 2020 TBD, SAS. All rights reserved.
 * Developer: Pierre-Louis HUBERT <pierre-louis.hubert@agence-tbd.com>
 */


namespace Mywindparts\Bundle\CatalogBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MywindpartsCatalogBundle extends Bundle
{
}

