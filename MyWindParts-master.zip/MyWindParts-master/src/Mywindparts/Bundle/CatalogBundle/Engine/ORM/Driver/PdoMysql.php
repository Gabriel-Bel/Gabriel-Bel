<?php
namespace Mywindparts\Bundle\CatalogBundle\Engine\ORM\Driver;

class PdoMysql extends \Oro\Bundle\WebsiteSearchBundle\Engine\ORM\Driver\PdoMysql
{

    /**
     * Search for SKU
     *
     * @param string $fieldName
     * @param array|string $fieldValue
     * @return array|string
     */
    protected function filterTextFieldValue($fieldName, $fieldValue)
    {
        if( $fieldValue
            && strpos($fieldName, 'all_text_') === 0
            && preg_match('/MWP-.+-(.*)/', $fieldValue, $matches) ) {
            $fieldValue = $matches[1];
        }

        return parent::filterTextFieldValue($fieldName, $fieldValue);
    }

}