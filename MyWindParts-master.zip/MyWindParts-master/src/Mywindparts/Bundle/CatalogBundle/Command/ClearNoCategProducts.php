<?php

namespace Mywindparts\Bundle\CatalogBundle\Command;

use Doctrine\Persistence\ObjectManager;
use Oro\Bundle\EntityBundle\ORM\DoctrineHelper;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Oro\Bundle\CatalogBundle\Entity\Category;
use Oro\Bundle\ProductBundle\Entity\Product;
use Oro\Bundle\ProductBundle\Entity\Repository\ProductRepository;
use Oro\Bundle\CatalogBundle\Entity\Repository\CategoryRepository;
use Symfony\Component\DependencyInjection\ParameterBag\ParameterBagInterface;
use Doctrine\ORM\EntityManager;
use Psr\Log\LoggerInterface;
use Symfony\Component\Filesystem\Filesystem;

class ClearNoCategProducts extends Command
{
    protected static $defaultName = 'mwp:catalog:categorizeproducts';
    protected string $_shippingOptionFile = 'shippingOption.csv';
    protected ParameterBagInterface $parameterBag;
    protected ObjectManager $objectManager;
    protected LoggerInterface $logger;
    protected Filesystem $filesystem;
    private DoctrineHelper $doctrineHelper;
    private EntityManager $entityManager;

    public function __construct(DoctrineHelper        $doctrineHelper,
                                EntityManager         $entityManager,
                                ParameterBagInterface $parameterBag,
                                ObjectManager         $objectManager,
                                LoggerInterface       $logger,
                                Filesystem            $filesystem)
    {
        parent::__construct();
        $this->doctrineHelper = $doctrineHelper;
        $this->entityManager = $entityManager;
        $this->parameterBag = $parameterBag;
        $this->objectManager = $objectManager;
        $this->logger = $logger;
        $this->filesystem = $filesystem;
    }


    public function configure()
    {
        $this
            ->setDescription('Met à jour tous les produits non catégorisés et leur affecte l\'ID de la catégorie NewProduct')
            ->setHelp($this->getDescription());
        parent::configure();
    }

    public function execute(InputInterface $input, OutputInterface $output)
    {

        /** @var CategoryRepository $categoryRepository */
        $categoryRepository = $this->doctrineHelper->getEntityRepository(Category::class);
        /** @var Category $newProductCategory */
        $newProductCategory = $categoryRepository->findOneBy([
            'denormalizedDefaultTitle' => 'NewProduct',
        ]);

        if(!$newProductCategory){
            throw new \Exception("'NewProduct' category not found. Please create a new category named 'NewProduct' to allow categorize of category-less products.");
        }

        $this->entityManager->getConnection()
                ->executeQuery('UPDATE oro_product AS op SET op.category_id = '.$newProductCategory->getId().
                    ' where op.category_id is null');

        $this->setProductsShippingOption();
    }

    protected function setProductsShippingOption()
    {
        /** @var ProductRepository $productRepository */
        $productRepository = $this->doctrineHelper->getEntityRepository(Product::class);
        $importsFilesPath = $this->parameterBag->get('imports_files_path'). $this->_shippingOptionFile;
        if(!$this->filesystem->exists($importsFilesPath)){
            return false;
        }

        $sqlUpdateShipping = "INSERT INTO oro_shipping_product_opts (freight_class_code, product_id, product_unit_code, dimensions_unit_code, weight_unit_code, 
                        weight_value, dimensions_length, dimensions_width, dimensions_height) 
                        VALUES (:freight_class_code, :product_id, :product_unit_code, :dimensions_unit_code, :weight_unit_code, 
                                :weight_value, :dimensions_length, :dimensions_width, :dimensions_height)
                        ON DUPLICATE KEY UPDATE
                        freight_class_code = VALUES(freight_class_code),  dimensions_unit_code = VALUES(dimensions_unit_code),
                        weight_unit_code = VALUES(weight_unit_code), weight_value = VALUES(weight_value),
                        dimensions_length = VALUES(dimensions_length), dimensions_width = VALUES(dimensions_width),
                        dimensions_height = VALUES(dimensions_height)
                        ;";

        $sqlSelect = "SELECT * FROM oro_shipping_product_opts WHERE product_id=:product_id";

        $handle = fopen($importsFilesPath, "r");
        while (($data = fgetcsv($handle, 1000)) !== FALSE) {

            //Mise en place du tableau $headerCsv qui permettra de facilement retrouver une colonne par son nom
            if (empty($headerCsv)) {
                $headerCsv = $data;
                $headerIdByName = array_flip($data);
                continue;
            }

            try {
                /** @var Product $product */
                $product = $productRepository->findOneBySku($data[$headerIdByName['sku']]);
                if(!$product || !$product->getId()) {
                    continue;
                }

                $shippingOptionsCount = $this->entityManager->getConnection()->executeStatement($sqlSelect, ['product_id'=>$product->getId()]);
                if($shippingOptionsCount>0) {
                    continue;
                }

                $productUnitCode  = $data[$headerIdByName['primaryUnitPrecision.unit.code']];
                $weightValue      = $data[$headerIdByName['shipping_options[weight][value]']];
                $weightUnit       = $data[$headerIdByName['shipping_options[weight][unit]']];
                $dimensionsLength = $data[$headerIdByName['shipping_options[dimensions][value][length]']];
                $dimensionsWidth  = $data[$headerIdByName['shipping_options[dimensions][value][width]']];
                $dimensionsHeight = $data[$headerIdByName['shipping_options[dimensions][value][height]']];

                if(empty($product) || $weightValue == 0 || $dimensionsLength == 0 || $dimensionsWidth == 0 || $dimensionsHeight == 0){
                    continue;
                }

                $params = [
                    'freight_class_code' => 'parcel',
                    'product_id' => $product->getId(),
                    'product_unit_code' => $this->toLowerBasic($productUnitCode),
                    'dimensions_unit_code' => 'cm',
                    'weight_unit_code' => $weightUnit,
                    'weight_value' => $this->castFloat($weightValue),
                    'dimensions_length' => $this->castFloat($dimensionsLength),
                    'dimensions_width' => $this->castFloat($dimensionsWidth),
                    'dimensions_height' => $this->castFloat($dimensionsHeight),
                ];

                $types = [
                    'values' => 'string'
                ];
                $this->entityManager->getConnection()->executeStatement($sqlUpdateShipping, $params, $types);

            } catch (\Exception $exception){
                $this->logger->error('Error while inserting oro shipping option', ['exception' => $exception,'message' => $exception->getMessage()]);
            }
        }
        fclose($handle);

        if($this->filesystem->exists($importsFilesPath)){
            $this->filesystem->remove($importsFilesPath);
        }
    }

    /**
     * @param $number
     * @return array|string|string[]
     */
    private function castFloat($number)
    {
        return str_replace(',', '.', $number);
    }

    /**
     * @param $string
     * @return array|string|string[]
     */
    private function toLowerBasic($string)
    {
        $search  = array('À', 'Á', 'Â', 'Ã', 'Ä', 'Å', 'Ç', 'È', 'É', 'Ê', 'Ë', 'Ì', 'Í', 'Î', 'Ï', 'Ò', 'Ó', 'Ô', 'Õ', 'Ö', 'Ù', 'Ú', 'Û', 'Ü', 'Ý', 'à', 'á', 'â', 'ã', 'ä', 'å', 'ç', 'è', 'é', 'ê', 'ë', 'ì', 'í', 'î', 'ï', 'ð', 'ò', 'ó', 'ô', 'õ', 'ö', 'ù', 'ú', 'û', 'ü', 'ý', 'ÿ');
        $replace = array('A', 'A', 'A', 'A', 'A', 'A', 'C', 'E', 'E', 'E', 'E', 'I', 'I', 'I', 'I', 'O', 'O', 'O', 'O', 'O', 'U', 'U', 'U', 'U', 'Y', 'a', 'a', 'a', 'a', 'a', 'a', 'c', 'e', 'e', 'e', 'e', 'i', 'i', 'i', 'i', 'o', 'o', 'o', 'o', 'o', 'o', 'u', 'u', 'u', 'u', 'y', 'y');

        return str_replace($search, $replace, strtolower($string));
    }
}