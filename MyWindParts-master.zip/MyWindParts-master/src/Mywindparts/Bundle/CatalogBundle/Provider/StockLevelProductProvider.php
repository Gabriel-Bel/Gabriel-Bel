<?php

namespace Mywindparts\Bundle\CatalogBundle\Provider;

use Oro\Bundle\EntityBundle\Exception\Fallback\FallbackFieldConfigurationMissingException;
use Oro\Bundle\EntityBundle\Exception\Fallback\InvalidFallbackKeyException;
use Oro\Bundle\EntityBundle\Fallback\EntityFallbackResolver;
use Oro\Bundle\EntityBundle\ORM\DoctrineHelper;
use Oro\Bundle\InventoryBundle\Entity\InventoryLevel;
use Oro\Bundle\InventoryBundle\Entity\Repository\InventoryLevelRepository;
use Oro\Bundle\InventoryBundle\Inventory\InventoryQuantityManager;
use Oro\Bundle\ProductBundle\Entity\Product;
use Oro\Bundle\ProductBundle\Entity\ProductUnit;
use Oro\Bundle\ProductBundle\Formatter\UnitValueFormatterInterface;

class StockLevelProductProvider extends \Oro\Bundle\InventoryBundle\Provider\InventoryQuantityProvider
{
    /**
     * @var EntityFallbackResolver
     */
    private $entityFallbackResolver;
    /**
     * @var UnitValueFormatterInterface
     */
    private $unitValueFormatter;

    public function __construct(DoctrineHelper $doctrineHelper,
                                InventoryQuantityManager $quantityManager,
                                EntityFallbackResolver $entityFallbackResolver,
                                UnitValueFormatterInterface $unitValueFormatter
    )
    {
        parent::__construct($doctrineHelper, $quantityManager);
        $this->entityFallbackResolver = $entityFallbackResolver;
        $this->unitValueFormatter = $unitValueFormatter;
    }

    public function getStockLevel(Product $product)
    {
        $availableQuantity = parent::getAvailableQuantity($product, $this->getDefaultProductUnit($product));
        return floor($availableQuantity);
    }

    public function getStockLevelWithUnit(Product $product)
    {
        return $this->unitValueFormatter->format($this->getStockLevel($product), $this->getDefaultProductUnit($product));
    }



    /**
     * Returns default Product Unit
     *
     * @param Product $product
     *
     * @return null|ProductUnit returns ProductUnit or null in exceptional case
     *
     */
    public function getDefaultProductUnit(Product $product)
    {
        if ($product->getPrimaryUnitPrecision() !== null) {
            $productUnit = $product->getPrimaryUnitPrecision()->getUnit();
        } else {
            $productUnit = null;
        }

        return $productUnit;
    }

}