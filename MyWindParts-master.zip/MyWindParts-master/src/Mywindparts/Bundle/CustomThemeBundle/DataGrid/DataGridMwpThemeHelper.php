<?php


namespace Mywindparts\Bundle\CustomThemeBundle\DataGrid;


class DataGridMwpThemeHelper extends \Oro\Bundle\ProductBundle\DataGrid\DataGridThemeHelper
{
    /**
     * @return string
     */
    protected function getDefaultView()
    {
        return self::VIEW_TILES;
    }
}