<?php

namespace Mywindparts\Bundle\CustomThemeBundle\Twig;

use Oro\Bundle\OrderBundle\Provider\OrderStatusesProviderInterface;
use Symfony\Contracts\Translation\TranslatorInterface;
use Psr\Container\ContainerInterface;
use Symfony\Contracts\Service\ServiceSubscriberInterface;
use Twig\Extension\AbstractExtension;
use Twig\TwigFunction;


class OrderStatusExtension extends AbstractExtension implements ServiceSubscriberInterface
{
    const ORDER_STATUS_EXTENSION_NAME = 'mwp_order_status';

    /**
     * @var TranslatorInterface
     */
    private $translator;


    /**
     * OrderStatusExtension constructor.
     * @param TranslatorInterface $translator
     */
    public function __construct(TranslatorInterface $translator
    )
    {
        $this->translator = $translator;
    }

    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return static::ORDER_STATUS_EXTENSION_NAME;
    }

    /**
     * @return array
     */
    public function getFunctions()
    {
        return [
            new TwigFunction(
                'get_order_status',
                [$this, 'getOrderStatus']
            )
        ];
    }

    /**
     * @param object $entity
     *
     * @return string
     */
    public function getOrderStatus($orderStatus)
    {
        return $this->translator->trans(sprintf('mwp.order.status.%s', strtolower($orderStatus)));
    }

    public static function getSubscribedServices()
    {
        return [];
    }
}
