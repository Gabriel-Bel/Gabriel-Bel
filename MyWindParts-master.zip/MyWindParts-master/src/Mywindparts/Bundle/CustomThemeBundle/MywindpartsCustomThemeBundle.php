<?php
/*
 * Copyright (c) 2014 - 2020 TBD, SAS. All rights reserved.
 * Developer: Pierre-Louis HUBERT <pierre-louis.hubert@agence-tbd.com>
 */


namespace Mywindparts\Bundle\CustomThemeBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MywindpartsCustomThemeBundle extends Bundle
{
    public function getParent()
    {
        return 'OroCustomThemeBundle';
    }
}

