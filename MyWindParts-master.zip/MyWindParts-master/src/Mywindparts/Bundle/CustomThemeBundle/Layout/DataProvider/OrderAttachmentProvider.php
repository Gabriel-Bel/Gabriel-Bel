<?php

namespace Mywindparts\Bundle\CustomThemeBundle\Layout\DataProvider;

use Oro\Bundle\AttachmentBundle\Manager\AttachmentManager;
use Oro\Bundle\AttachmentBundle\Provider\AttachmentProvider;
use Oro\Bundle\AttachmentBundle\Provider\FileUrlProviderInterface;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

class OrderAttachmentProvider
{
    /** @var AttachmentProvider */
    protected $attachmentProvider;

    /** @var AttachmentManager */
    protected $attachmentManager;

    public function __construct(
        AttachmentProvider $attachmentProvider,
        AttachmentManager  $attachmentManager
    )
    {
        $this->attachmentProvider = $attachmentProvider;
        $this->attachmentManager = $attachmentManager;
    }

    public function getAttachmentProviderForOrder($entity)
    {
        $orderAttachmentsFilesUrl = [];
        $orderAttachments = $this->attachmentProvider->getEntityAttachments($entity);
        if ($orderAttachments) {
            foreach ($orderAttachments as $orderAttachment){
                $file = $orderAttachment->getFile();
                $fileId = $file->getId();
                $fileUrl = $this->attachmentManager->getFileUrl(
                    $file,
                    FileUrlProviderInterface::FILE_ACTION_DOWNLOAD,
                    UrlGeneratorInterface::ABSOLUTE_URL
                );
                $orderAttachmentsFilesUrl[$fileId]['filename'] = $file->getOriginalFilename();
                $orderAttachmentsFilesUrl[$fileId]['url'] = $fileUrl;
            }
        }
        return $orderAttachmentsFilesUrl;
    }
}
