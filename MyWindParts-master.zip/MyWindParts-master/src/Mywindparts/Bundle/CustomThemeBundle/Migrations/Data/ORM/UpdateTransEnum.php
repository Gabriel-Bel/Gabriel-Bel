<?php
namespace Mywindparts\Bundle\CustomThemeBundle\Migrations\Data\ORM;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Persistence\ObjectManager;
use Oro\Bundle\EntityExtendBundle\Entity\EnumValueTranslation;
use Oro\Bundle\EntityExtendBundle\Tools\ExtendHelper;
use Oro\Bundle\OrderBundle\Entity\Order;


class UpdateTransEnum extends AbstractFixture
{

    public function load(ObjectManager $em)
    {
        $className = ExtendHelper::buildEnumValueClassName(Order::INTERNAL_STATUS_CODE);
        $statusTranslation = [
            'closed' => 'Livrée',
            'open' => 'En cours de traitement',
        ];

        $enumValueTranslation = $em->getRepository(EnumValueTranslation::class);

        foreach ($statusTranslation as $statusKey => $statusLabel) {
            $status = $enumValueTranslation->findOneBy([
                'field' => 'name',
                'locale' => 'fr_FR',
                'foreignKey' => $statusKey
            ]);
            $status->setContent($statusLabel);
            $em->persist($status);
        }
        $em->flush();
    }
}