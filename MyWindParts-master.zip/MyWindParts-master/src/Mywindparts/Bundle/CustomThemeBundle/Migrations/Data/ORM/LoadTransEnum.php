<?php
namespace Mywindparts\Bundle\CustomThemeBundle\Migrations\Data\ORM;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Persistence\ObjectManager;
use Oro\Bundle\EntityExtendBundle\Entity\EnumValueTranslation;
use Oro\Bundle\EntityExtendBundle\Tools\ExtendHelper;
use Oro\Bundle\OrderBundle\Entity\Order;

class LoadTransEnum extends AbstractFixture
{
    public function load(ObjectManager $em)
    {
        $className = ExtendHelper::buildEnumValueClassName(Order::INTERNAL_STATUS_CODE);

        $statusTranslation = [
            'archived' => 'Archivée',
            'cancelled' => 'Annulée',
            'closed' => 'Cloturée',
            'open' => 'En cours',
            'shipped' => 'Expédiée',
        ];

        foreach ($statusTranslation as $statusKey=>$statusLabel) {
            $enumValueTranslation = new  EnumValueTranslation();
            $enumValueTranslation
                ->setForeignKey($statusKey)
                ->setContent($statusLabel)
                ->setLocale('fr_FR')
                ->setObjectClass($className)
                ->setField('name');

            $em->persist($enumValueTranslation);
        }
        $em->flush();
    }
}