<?php
namespace Mywindparts\Bundle\CustomThemeBundle\Migrations\Data\ORM;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Persistence\ObjectManager;
use Oro\Bundle\EntityExtendBundle\Entity\EnumValueTranslation;
use Oro\Bundle\EntityExtendBundle\Tools\ExtendHelper;
use Oro\Bundle\ProductBundle\Entity\Product;

class LoadInventoryStatusTransEnum extends AbstractFixture
{
    public function load(ObjectManager $em)
    {
        $className = ExtendHelper::buildEnumValueClassName('prod_inventory_status');

        $statusTranslation = [
            Product::INVENTORY_STATUS_DISCONTINUED => 'Abandonné',
            Product::INVENTORY_STATUS_IN_STOCK => 'En Stock',
            Product::INVENTORY_STATUS_OUT_OF_STOCK => 'En rupture de stock',
        ];

        foreach ($statusTranslation as $statusKey=>$statusLabel) {
            $enumValueTranslation = new  EnumValueTranslation();
            $enumValueTranslation
                ->setForeignKey($statusKey)
                ->setContent($statusLabel)
                ->setLocale('fr_FR')
                ->setObjectClass($className)
                ->setField('name');

            $em->persist($enumValueTranslation);
        }
        $em->flush();
    }
}