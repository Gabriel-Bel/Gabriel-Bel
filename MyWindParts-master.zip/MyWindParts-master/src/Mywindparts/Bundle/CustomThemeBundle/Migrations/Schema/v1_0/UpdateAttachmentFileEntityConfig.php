<?php
namespace Mywindparts\Bundle\CustomThemeBundle\Migrations\Schema\v1_0;

use Doctrine\DBAL\Schema\Schema;
use Oro\Bundle\AttachmentBundle\Entity\Attachment;
use Oro\Bundle\MigrationBundle\Migration\Migration;
use Oro\Bundle\MigrationBundle\Migration\QueryBag;
use Oro\Bundle\EntityConfigBundle\Migration\UpdateEntityConfigFieldValueQuery;

class UpdateAttachmentFileEntityConfig implements  Migration
{
    public function up(Schema $schema, QueryBag $queries)
    {
        $queries->addQuery(
            new UpdateEntityConfigFieldValueQuery(
                Attachment::class,
                "file",
                'attachment',
                'file_applications',
                ["commerce", "default"]
            )
        );
    }
}