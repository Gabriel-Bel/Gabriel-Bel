<?php

namespace Mywindparts\Bundle\CustomThemeBundle\Entity;

use Oro\Bundle\AttachmentBundle\Provider\AttachmentProvider;
use Oro\Bundle\LayoutBundle\Layout\Block\Type\ConfigurableType;

class OrderAttachment extends ConfigurableType
{
    protected $attachmentProvider;

    public function __construct(AttachmentProvider $attachmentProvider) {
        $this->attachmentProvider = $attachmentProvider;
    }
}