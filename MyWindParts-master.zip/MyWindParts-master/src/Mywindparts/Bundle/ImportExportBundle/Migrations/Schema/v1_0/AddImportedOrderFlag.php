<?php
namespace Mywindparts\Bundle\ImportExportBundle\Migrations\Schema\v1_0;

use Doctrine\DBAL\Schema\Schema;
use Oro\Bundle\EntityBundle\EntityConfig\DatagridScope;
use Oro\Bundle\MigrationBundle\Migration\Migration;
use Oro\Bundle\MigrationBundle\Migration\QueryBag;
use Oro\Bundle\EntityExtendBundle\EntityConfig\ExtendScope;
use Oro\Bundle\EntitySerializedFieldsBundle\Migration\Extension\SerializedFieldsExtension;
use Oro\Bundle\EntitySerializedFieldsBundle\Migration\Extension\SerializedFieldsExtensionAwareInterface;

class AddImportedOrderFlag implements
    Migration,
    SerializedFieldsExtensionAwareInterface
{
    /** @var SerializedFieldsExtension */
    protected $serializedFieldsExtension;

    /**
     * {@inheritdoc}
     */
    public function setSerializedFieldsExtension(SerializedFieldsExtension $serializedFieldsExtension)
    {
        $this->serializedFieldsExtension = $serializedFieldsExtension;
    }

    /**
     * {@inheritdoc}
     */
    public function up(Schema $schema, QueryBag $queries)
    {
        $table = $schema->getTable('oro_order');
        $table->addColumn(
            'sageImported',
            'boolean',
            [
                'notnull' => true,
                'default' => false,
                'oro_options' => [
                    'entity' => ['label' => 'mwp.sage.imported', 'description' => 'Flag to know if the order was imported into Sage ERP'],
                    'extend' => [ 'is_extend' => true,'owner' => ExtendScope::OWNER_CUSTOM],
                    'view' => ['is_displayable' => true],
                    'importexport' => ['excluded' => false],
                    'datagrid' => ['is_visible' => DatagridScope::IS_VISIBLE_TRUE],
                    'form' => ['is_enabled' => false],
                    'merge' => ['display' => false],
                ]
            ]
        );

    }
}