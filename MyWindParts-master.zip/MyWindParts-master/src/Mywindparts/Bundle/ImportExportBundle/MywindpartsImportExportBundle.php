<?php

namespace Mywindparts\Bundle\ImportExportBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MywindpartsImportExportBundle extends Bundle
{

}
