<?php

namespace Mywindparts\Bundle\ImportExportBundle\Command;

use Doctrine\Persistence\ObjectManager;
use Doctrine\Persistence\ManagerRegistry;
use Oro\Bundle\EmailBundle\Mailer\Processor;
use Oro\Bundle\EntityBundle\ORM\DoctrineHelper;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Oro\Bundle\InventoryBundle\Entity\Repository\InventoryLevelRepository;
use Oro\Bundle\InventoryBundle\Entity\InventoryLevel;
use Oro\Bundle\ProductBundle\Entity\Repository\ProductRepository;
use Mywindparts\Bundle\CatalogBundle\Provider\StockLevelProductProvider;
use Symfony\Component\DependencyInjection\ParameterBag\ParameterBagInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\Filesystem\Filesystem;

class ImportProductsStocks extends AbstractCommand
{
    protected static $defaultName = 'mwp:importexport:importproductstock';
    protected string $_sftpFilename = 'stocks.csv';
    protected LoggerInterface $logger;
    protected DoctrineHelper $doctrineHelper;
    protected ObjectManager $objectManager;
    protected ManagerRegistry $managerRegistry;
    protected StockLevelProductProvider $stockLevelProductProvider;
    protected ProductRepository $productRepository;

    public function __construct(ParameterBagInterface $parameterBag,
                                LoggerInterface $logger,
                                Filesystem $filesystem,
                                DoctrineHelper $doctrineHelper,
                                Processor $mailerProcessor,
                                ObjectManager $objectManager,
                                ManagerRegistry $managerRegistry,
                                StockLevelProductProvider $stockLevelProductProvider,
                                ProductRepository $productRepository)
    {
        parent::__construct($parameterBag, $logger, $filesystem, $doctrineHelper, $mailerProcessor);
        $this->objectManager = $objectManager;
        $this->managerRegistry = $managerRegistry;
        $this->stockLevelProductProvider = $stockLevelProductProvider;
        $this->productRepository = $productRepository;
    }


    public function configure()
    {
        $this
            ->setDescription('Import des nouveaux stocks de produits')
            ->setHelp($this->getDescription())
        ;
        parent::configure();
    }

    public function doExecute(InputInterface $input, OutputInterface $output)
    {
        $unknownsSku = [];
        $csvContent = $this->getFileContent($this->getConfigParameterByCode('ftp_import_files_path'), $this->_sftpFilename);

        if($csvContent && $csvStock = $this->getCsvContentAsArray($csvContent)){
            /** @var InventoryLevelRepository $inventoryLevelRepository */
            $inventoryLevelRepository = $this->doctrineHelper->getEntityRepository(InventoryLevel::class);
            foreach ($csvStock as $newStockLine){
                $sku = $newStockLine[0];
                $newStockValue = $newStockLine[1];
                $product = $this->productRepository->findOneBySku($sku);
                if(!$product){
                    array_push($unknownsSku, $sku);
                    continue;
                }
                try{
                    $productUnit = $this->stockLevelProductProvider->getDefaultProductUnit($product);
                    $inventoryLevel = $inventoryLevelRepository->getLevelByProductAndProductUnit($product, $productUnit);
                    $inventoryLevel->setQuantity($newStockValue);
                    $this->objectManager->persist($inventoryLevel);
                    $this->objectManager->flush();
                }catch(\Exception $exception){
                    if (!$this->objectManager->isOpen()) {
                        $this->managerRegistry->resetManager();
                    }
                    $this->logger->error(sprintf('Error occurred while updating %s stock', $sku),
                        [
                            'exception' => $exception,
                            'message' => $exception->getMessage()
                        ]
                    );
                }
            }
            if(!empty($unknownsSku)){
                $this->logger->notice('SKU manquants : '.implode(',', $unknownsSku));
            }else{
                $this->logger->notice('Tous les SKU traité ont été retrouvés dans la base de données ORO.');
            }
            $output->writeln('Import has finish, the missing SKU are listing in logs.');
            $filename = $this->renameFile($this->_sftpFilename);
            if($this->putFileOnSftpServer($this->getConfigParameterByCode('ftp_import_archives_path'), $filename)){
                $this->deleteLocalFile($filename);
            }
        }else{
            $this->logger->notice('No file was found.');
            $output->writeln('No file was found.');
        }
    }
}