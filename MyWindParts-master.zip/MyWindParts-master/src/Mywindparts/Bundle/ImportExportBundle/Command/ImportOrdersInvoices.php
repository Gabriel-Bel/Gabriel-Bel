<?php

namespace Mywindparts\Bundle\ImportExportBundle\Command;

use Doctrine\Persistence\ManagerRegistry;
use Doctrine\Persistence\ObjectManager;
use Oro\Bundle\EntityExtendBundle\Tools\ExtendHelper;
use Oro\Bundle\OrderBundle\Entity\Repository\OrderRepository;
use Oro\Bundle\OrderBundle\Entity\Order;
use Oro\Bundle\EmailBundle\Mailer\Processor;
use Oro\Bundle\EntityBundle\ORM\DoctrineHelper;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\DependencyInjection\ParameterBag\ParameterBagInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\Filesystem\Filesystem;
use Oro\Bundle\AttachmentBundle\Entity\Attachment;
use Oro\Bundle\AttachmentBundle\Entity\File;
use Symfony\Component\HttpFoundation\File\File as SymfonyFile;
use Oro\Bundle\UserBundle\Entity\User;
use Oro\Bundle\UserBundle\Entity\Repository\UserRepository;
use Oro\Bundle\EntityExtendBundle\Entity\AbstractEnumValue;

class ImportOrdersInvoices extends AbstractCommand
{
    /**
     * Admin User who's gonna ba attached to new files
     * @var User
     */
    protected $_adminUser;
    /**
     * Closed Internal Status Code Object
     * @var AbstractEnumValue
     */
    protected $_closedInternalStatusCode;
    protected static $defaultName = 'mwp:importexport:importordersinvoices';
    protected string $_invoiceFilesPrefix = 'MWP-FACTURE-';
    protected int $_adminUserId = 1;
    protected bool $_sendLogMail = false;
    private ObjectManager $objectManager;
    private ManagerRegistry $managerRegistry;

    public function __construct(ParameterBagInterface $parameterBag,
                                LoggerInterface       $logger,
                                Filesystem            $filesystem,
                                DoctrineHelper        $doctrineHelper,
                                Processor             $mailerProcessor,
                                ObjectManager         $objectManager,
                                ManagerRegistry       $managerRegistry)
    {
        parent::__construct($parameterBag, $logger, $filesystem, $doctrineHelper, $mailerProcessor);
        $this->objectManager = $objectManager;
        $this->managerRegistry = $managerRegistry;
    }

    public function configure()
    {
        $this
            ->setDescription('Import Order Invoices from Sage and set order to closed')
            ->setHelp($this->getDescription());
        parent::configure();
    }

    public function doExecute(InputInterface $input, OutputInterface $output)
    {
        $ftpFilePath = $this->getConfigParameterByCode('ftp_import_invoices_path');
        $localFilesPath = $this->getConfigParameterByCode('imports_files_path');
        $filesList = $this->getFilesList($ftpFilePath, $this->_invoiceFilesPrefix);

        /** @var UserRepository $userRepository */
        $userRepository = $this->doctrineHelper->getEntityRepository(User::class);
        $this->_adminUser = $userRepository->findOneBy(['id' => $this->_adminUserId]);

        $this->_closedInternalStatusCode = $this->objectManager->getRepository(ExtendHelper::buildEnumValueClassName(Order::INTERNAL_STATUS_CODE))->findOneBy(['id' => 'closed']);

        foreach ($filesList as $filename) {
            $output->writeln('Début du traitement du fichier ' . $filename);
            $orderNumber = str_replace([$this->_invoiceFilesPrefix, '.pdf'], '', $filename);

            $fileContent = $this->getFileContent($ftpFilePath, $filename);
            if ($fileContent) {
                /** @var OrderRepository $orderRepository */
                $orderRepository = $this->doctrineHelper->getEntityRepository(Order::class);
                $order = $orderRepository->findOneBy(["id" => $orderNumber]);

                if ($this->addInvoiceToOrder($order, $localFilesPath . $filename)) {
                    $this->setOrderToClosed($order);
                    $output->writeln('Fichier ' . $filename . ' traité avec succès.');
                    if ($this->putFileOnSftpServer($this->getConfigParameterByCode('ftp_import_invoices_archive_path'), $filename)) {
                        $this->deleteLocalFile($filename);
                    }
                }
            }
        }
    }

    /**
     * @param Order $order
     * @param $file
     * @return boolean
     */
    protected function addInvoiceToOrder(Order $order, $file): bool
    {
        try {
            $newFile = new File();
            $attachmentEntity = new Attachment();
            $symfonyFile = new SymfonyFile($file);

            $newFile
                ->setOriginalFilename($symfonyFile->getFilename())
                ->setOwner($this->_adminUser)
                ->setParentEntityClass(Attachment::class)
                ->setParentEntityFieldName('file')
                ->setParentEntityId($attachmentEntity->getId())
                ->setFile($symfonyFile);
            $attachmentEntity
                ->setFile($newFile)
                ->setComment('Facture pour la commande' . $order->getId())
                ->setOrganization($this->_adminUser->getOrganization())
                ->setTarget($order)
                ->setOwner($this->_adminUser);

            $this->objectManager->persist($attachmentEntity);
            $this->objectManager->persist($newFile);
            $this->objectManager->flush();
            return true;
        } catch (\Exception $exception) {
            $this->_sendLogMail = true;
            if (!$this->objectManager->isOpen()) {
                $this->managerRegistry->resetManager();
            }
            $this->logger->error('Error while Attachment file creation',
                [
                    'exception' => $exception,
                    'message' => $exception->getMessage()
                ]
            );
            return false;
        }
    }

    /**
     * @param Order $order
     * @return boolean
     */
    protected function setOrderToClosed(Order $order): bool
    {
        try {
            $order->setInternalStatus($this->_closedInternalStatusCode);
            $this->objectManager->persist($order);
            $this->objectManager->flush();
            return true;
        } catch (\Exception $exception) {
            $this->_sendLogMail = true;
            if (!$this->objectManager->isOpen()) {
                $this->managerRegistry->resetManager();
            }
            $this->logger->error('Error while Order InternalStatus set on Closed for order: ' . $order->getId(),
                [
                    'exception' => $exception,
                    'message' => $exception->getMessage()
                ]
            );
            return false;
        }
    }
}