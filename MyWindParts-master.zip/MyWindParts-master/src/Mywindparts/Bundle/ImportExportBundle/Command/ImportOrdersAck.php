<?php

namespace Mywindparts\Bundle\ImportExportBundle\Command;

use Doctrine\Persistence\ManagerRegistry;
use Doctrine\Persistence\ObjectManager;
use Oro\Bundle\OrderBundle\Entity\Repository\OrderRepository;
use Oro\Bundle\OrderBundle\Entity\Order;
use Oro\Bundle\EmailBundle\Mailer\Processor;
use Oro\Bundle\EntityBundle\ORM\DoctrineHelper;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\DependencyInjection\ParameterBag\ParameterBagInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\Filesystem\Filesystem;

class ImportOrdersAck extends AbstractCommand
{
    protected static $defaultName = 'mwp:importexport:importordersack';
    protected string $_ackFilesPrefix = 'MWP-CMD-ACK-';
    protected bool $_sendLogMail = false;
    private ObjectManager $objectManager;
    private ManagerRegistry $managerRegistry;

    public function __construct(ParameterBagInterface $parameterBag,
                                LoggerInterface       $logger,
                                Filesystem            $filesystem,
                                DoctrineHelper        $doctrineHelper,
                                Processor             $mailerProcessor,
                                ObjectManager         $objectManager,
                                ManagerRegistry       $managerRegistry)
    {
        parent::__construct($parameterBag, $logger, $filesystem, $doctrineHelper, $mailerProcessor);
        $this->objectManager = $objectManager;
        $this->managerRegistry = $managerRegistry;
    }

    public function configure()
    {
        $this
            ->setDescription('Import Order Acknowledgment to set sageImported on true')
            ->setHelp($this->getDescription());
        parent::configure();
    }

    public function doExecute(InputInterface $input, OutputInterface $output)
    {
        $ftpFilePath = $this->getConfigParameterByCode('ftp_import_orders_path');
        $filesList = $this->getFilesList($ftpFilePath, $this->_ackFilesPrefix);

        foreach ($filesList as $filename) {
            try {
                $output->writeln('Début du traitement du fichier ' . $filename);
                $orderNumber = str_replace([$this->_ackFilesPrefix, '.txt'], '', $filename);

                $fileContent = $this->getFileContent($ftpFilePath, $filename);
                if (!$fileContent) {
                    $this->logger->error('Erreur lors du traitement du ficher "' . $filename . '". Fichier potentiellement vide ou corrompu.');
                    $this->_sendLogMail = true;
                    continue;
                } elseif (!preg_match('/^OK/', $fileContent)) {
                    $this->logger->info('Sage send an Ack with a non "OK" content on '.$filename.' file. Please take a look on the content :', [$fileContent]);
                    $this->_sendLogMail = true;
                    continue;
                }

                /** @var OrderRepository $orderRepository */
                $orderRepository = $this->doctrineHelper->getEntityRepository(Order::class);
                $order = $orderRepository->findOneBy(["id" => $orderNumber]);
                if ($this->setSageImportedOnTrue($order)) {
                    $output->writeln('Fichier ' . $filename . ' traité avec succès.');
                    if ($this->putFileOnSftpServer($this->getConfigParameterByCode('ftp_import_orders_archive_path'), $filename)) {
                        $this->deleteLocalFile($filename);
                    }
                }
            } catch (\Exception $exception) {
                $this->logger->notice($exception);
                continue;
            }
        }
    }

    /**
     * @param Order $order
     * @return boolean
     */
    protected function setSageImportedOnTrue($order): bool
    {
        try {
            $order->setSageImported(true);
            $this->objectManager->persist($order);
            $this->objectManager->flush();
            return true;
        } catch (\Exception $exception) {
            $this->_sendLogMail = true;
            if (!$this->objectManager->isOpen()) {
                $this->managerRegistry->resetManager();
            }
            $this->logger->error('Error while Order SageImported set on true for order: ' . $order->getId(),
                [
                    'exception' => $exception,
                    'message' => $exception->getMessage()
                ]
            );
            return false;
        }
    }
}