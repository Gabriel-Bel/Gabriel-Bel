<?php

namespace Mywindparts\Bundle\ImportExportBundle\Command;

use Oro\Bundle\OrderBundle\Entity\Repository\OrderRepository;
use Oro\Bundle\OrderBundle\Entity\Order;
use Oro\Bundle\EmailBundle\Mailer\Processor;
use Oro\Bundle\EntityBundle\ORM\DoctrineHelper;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\DependencyInjection\ParameterBag\ParameterBagInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\Serializer\Serializer;
use Oro\Bundle\TaxBundle\Provider\TaxSubtotalProvider;
use Oro\Bundle\ShippingBundle\Translator\ShippingMethodLabelTranslator;
use Oro\Bundle\PaymentBundle\Entity\PaymentTransaction;
use Oro\Bundle\PaymentBundle\Entity\Repository\PaymentTransactionRepository;
use Oro\Bundle\PaymentBundle\Entity\PaymentMethodConfig;
use Oro\Bundle\PaymentBundle\Entity\Repository\PaymentMethodConfigRepository;

class ExportOrders extends AbstractCommand
{

    protected static $defaultName = 'mwp:importexport:exportorders';
    protected bool $_sendLogMail = false;
    private Serializer $serializer;
    private TaxSubtotalProvider $taxSubtotalProvider;
    private ShippingMethodLabelTranslator $shippingMethodLabelTranslator;

    public function __construct(ParameterBagInterface          $parameterBag,
                                LoggerInterface                $logger,
                                Filesystem                     $filesystem,
                                DoctrineHelper                 $doctrineHelper,
                                Processor                      $mailerProcessor,
                                Serializer                     $serializer,
                                ShippingMethodLabelTranslator  $shippingMethodLabelTranslator,
                                TaxSubtotalProvider            $taxSubtotalProvider
    )
    {
        parent::__construct($parameterBag, $logger, $filesystem, $doctrineHelper, $mailerProcessor);
        $this->serializer = $serializer;
        $this->shippingMethodLabelTranslator = $shippingMethodLabelTranslator;
        $this->taxSubtotalProvider = $taxSubtotalProvider;
    }

    public function configure()
    {
        $this
            ->setDescription('Export des commandes pour Sage')
            ->setHelp($this->getDescription());
        parent::configure();
    }

    public function doExecute(InputInterface $input, OutputInterface $output)
    {
        $startTime = date('Y-m-d-H');
        $this->logger->info("Start of the orders export from : " . $startTime);

        $importFilesPath = $this->getConfigParameterByCode('imports_files_path');

        /** @var PaymentTransactionRepository $paymentRepository */
        $paymentRepository = $this->doctrineHelper->getEntityRepository(PaymentTransaction::class);
        /** @var PaymentMethodConfigRepository $paymentMethodsConfigs */
        $paymentMethodsConfigs = $this->doctrineHelper->getEntityRepository(PaymentMethodConfig::class);


        /** @var OrderRepository $orders */
        $orders = $this->doctrineHelper->getEntityRepository(Order::class)
            ->createQueryBuilder('orders')
            ->leftJoin('orders.customerUser', 'cu')
            ->leftJoin('cu.customer', 'customer')
            ->andWhere('orders.internal_status = :open')
            ->andWhere('orders.sageImported = :notImported')
            ->setParameters([ 'open' => 'open', 'notImported' => 0])
            ->getQuery()
            ->getResult();


        /** @var Order $order */
        foreach ($orders as $order) {

            $orderData = [];
            try {

                if(!$order->getCustomerUser() || !$order->getCustomerUser()->getId()){
                    throw new \Exception("No Customer defined, so we don't export this order");
                }
                if(!$order->getCustomer() || !$order->getCustomer()->getMwpCodeClientSage()){
                    throw new \Exception("No Code Client Sage on this Customer, so we don't export this order");
                }
                if(!$order->getShippingCost() || empty((int)$order->getShippingCost()->getValue())){
                    throw new \Exception("Shipping cost equal to 0");
                }

                $orderData['order_id'] = $order->getId();
                $orderData['identifier'] = $order->getIdentifier();
                $orderData['poNumber'] = $order->getPoNumber();
                $orderData['currency'] = $order->getCurrency();
                $orderData['createdAt'] = $order->getCreatedAt()->format(DATE_RFC3339);
                $orderData['mwpCodeClientSage'] = $order->getCustomer()->getMwpCodeClientSage();

                if ($order->getSubtotalObject()) {
                    $orderData['subtotalValue'] = $order->getSubtotalObject()->getValue();
                    $orderData['subtotalCurrency'] = $order->getSubtotalObject()->getCurrency();
                }
                if ($order->getTotalObject()) {
                    $orderData['totalValue'] = $order->getTotalObject()->getValue();
                    $orderData['totalCurrency'] = $order->getTotalObject()->getCurrency();
                }

                $taxObject = $this->taxSubtotalProvider->getSubtotal($order);
                if ($taxObject) {
                    $orderData['taxTaxes'] = $taxObject->getData()['taxes'];
                    $orderData['taxTotal'] = $taxObject->getData()['total'];
                    $orderData['taxShipping'] = $taxObject->getData()['shipping'];
                }

                $orderData['customerNotes'] = $order->getCustomerNotes();
                $orderData['shipUntil'] = $order->getShipUntil();
                if (!empty($order->getShippingMethod()) && !empty($order->getShippingMethodType())) {
                    $orderData['shippingMethod'] = $order->getShippingMethod();
                    $shippingMethodLabel = $this->shippingMethodLabelTranslator->getShippingMethodWithTypeLabel($order->getShippingMethod(), $order->getShippingMethodType());
                    $orderData['shippingMethodLabel'] = $shippingMethodLabel;
                }
                if ($order->getShippingCost()) {
                    $orderData['shippingCostValue'] = $order->getShippingCost()->getValue();
                    $orderData['shippingCostCurrency'] = $order->getShippingCost()->getCurrency();
                }

                $orderData['shippingAddress'] = $order->getShippingAddress();
                $orderData['internalStatus'] = $order->getInternalStatus()->getId();


                $orderData['paymentTermId'] = '';
                $orderData['paymentTermLabel'] = '';
                if ($order->getPaymentTerm7c4f1e8e()) {
                    $orderData['paymentTermId'] = $order->getPaymentTerm7c4f1e8e()->getId();
                    $orderData['paymentTermLabel'] = $order->getPaymentTerm7c4f1e8e()->getLabel();
                }
                $paymentMethod = $paymentRepository->getPaymentMethods(Order::class, [$order->getId()]);
                $orderPaymentMethod = reset($paymentMethod[$order->getId()]);
                $methodConfig = $paymentMethodsConfigs->findOneBy(['type' => $orderPaymentMethod]);
                $orderData['paymentMethodType'] = $methodConfig->getType();
                $orderData['paymentMethodeRuleName'] = $methodConfig->getMethodsConfigsRule()->getRule()->getName();

                $lineItems = [];
                foreach ($order->getLineItems() as $lineItemProduct) {
                    $lineItem = [];
                    $lineItem['productSku'] = $lineItemProduct->getProductSku();
                    $lineItem['quantity'] = $lineItemProduct->getQuantity();

                    if ($lineItemProduct->getPrice()) {
                        $lineItem['priceValue'] = $lineItemProduct->getPrice()->getValue();
                        $lineItem['priceCurrency'] = $lineItemProduct->getPrice()->getCurrency();
                    }

                    $lineItemProductTax = $this->taxSubtotalProvider->getSubtotal($lineItemProduct);
                    $lineItem['productTaxes'] = $lineItemProductTax->getData();
                    $lineItems[] = $lineItem;
                }
                $orderData['lineItem'][] = $lineItems;

                $xmlEncode = $this->serializer->encode($orderData, 'xml', ['xml_encoding' => 'utf-8', 'xml_version' => '1.0']);
                $filename = 'MWP-CMD-' . $order->getId() . '.xml';
                $this->filesystem->dumpFile($importFilesPath . $filename, $xmlEncode);
                if ($this->putFileOnSftpServer($this->getConfigParameterByCode('ftp_export_orders_path'), $filename)) {
                    $this->deleteLocalFile($filename);
                }
            } catch (\Exception $exception) {
                $this->_sendLogMail = true;
                $this->logger->notice('Order id: '. $order->getId(), ['exception' => $exception]);
                continue;
            }
        }
        $this->logger->info("Orders export started at " . $startTime . " finish at : " . date('Y-m-d-H'));
    }
}