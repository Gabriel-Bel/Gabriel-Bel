<?php

namespace Mywindparts\Bundle\ImportExportBundle\Command;

use Doctrine\Persistence\ManagerRegistry;
use Doctrine\Persistence\ObjectManager;
use Oro\Bundle\EmailBundle\Mailer\Processor;
use Oro\Bundle\EntityBundle\ORM\DoctrineHelper;
use Oro\Bundle\PricingBundle\Entity\PriceListToCustomer;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\DependencyInjection\ParameterBag\ParameterBagInterface;
use Symfony\Component\Filesystem\Filesystem;
use Oro\Bundle\CustomerBundle\Entity\Repository\CustomerRepository;
use Oro\Bundle\CustomerBundle\Entity\Customer;
use Oro\Bundle\WebsiteBundle\Entity\Repository\WebsiteRepository;
use Oro\Bundle\WebsiteBundle\Entity\Website;
use Oro\Bundle\PricingBundle\Entity\Repository\PriceListRepository;
use Oro\Bundle\PricingBundle\Entity\PriceList;
use Oro\Bundle\PricingBundle\Entity\Repository\ProductPriceRepository;
use Oro\Bundle\PricingBundle\Entity\ProductPrice;
use Oro\Bundle\PricingBundle\Sharding\ShardManager;
use Oro\Bundle\ProductBundle\Entity\Repository\ProductRepository;
use Oro\Bundle\ProductBundle\Entity\Repository\ProductUnitRepository;
use Oro\Bundle\ProductBundle\Entity\ProductUnit;
use Oro\Bundle\CurrencyBundle\Entity\Price;
use Psr\Log\LoggerInterface;
use Oro\Bundle\PricingBundle\Entity\Repository\PriceListToProductRepository;
use Oro\Bundle\PricingBundle\Entity\PriceListToProduct;

class ImportPriceGrid extends AbstractCommand
{
    /**
     * Products Unit
     * @var ProductUnit
     */
    protected $_productUnits;
    protected static $defaultName = 'mwp:importexport:importpricegrid';
    protected string $_csvFilesPrefix = 'tarifs_';
    protected LoggerInterface $logger;
    protected DoctrineHelper $doctrineHelper;
    protected ObjectManager $objectManager;
    protected ManagerRegistry $managerRegistry;
    protected ShardManager $shardManager;
    protected ProductUnitRepository $productUnitRepository;
    protected ProductRepository $productRepository;

    public function __construct(ParameterBagInterface $parameterBag,
                                LoggerInterface $logger,
                                Filesystem $filesystem,
                                DoctrineHelper $doctrineHelper,
                                Processor $mailerProcessor,
                                ObjectManager $objectManager,
                                ManagerRegistry $managerRegistry,
                                ShardManager $shardManager,
                                ProductRepository $productRepository,
                                ProductUnitRepository $productUnitRepository
    )
    {
        parent::__construct($parameterBag, $logger, $filesystem, $doctrineHelper, $mailerProcessor);
        $this->objectManager = $objectManager;
        $this->managerRegistry = $managerRegistry;
        $this->shardManager = $shardManager;
        $this->productRepository = $productRepository;
        $this->productUnitRepository = $productUnitRepository;
    }


    public function configure()
    {
        $this
            ->setDescription('Import Price Grid')
            ->setHelp($this->getDescription())
        ;
        parent::configure();
    }

    public function doExecute(InputInterface $input, OutputInterface $output)
    {
        $ftpCsvPath = $this->getConfigParameterByCode('ftp_import_files_path');
        $filesList = $this->getFilesList($ftpCsvPath, 'tarifs_');
        $unknownsSku = array();
        $unknownsCustomersForCodeClient = array();
        $processedProductPrice = array();
        /** @var CustomerRepository $customerRepository */
        $customerRepository = $this->doctrineHelper->getEntityRepository(Customer::class);
        /** @var PriceListRepository $priceListRepository */
        $priceListRepository = $this->doctrineHelper->getEntityRepository(PriceList::class);
        /** @var ProductPriceRepository $productPriceRepository */
        $productPriceRepository = $this->doctrineHelper->getEntityRepository(ProductPrice::class);
        /** @var WebsiteRepository $websiteRepository */
        $websiteRepository = $this->doctrineHelper->getEntityRepository(Website::class);
        $defaultWebsite = $websiteRepository->getDefaultWebsite();
        /** @var PriceListToProductRepository $priceListToProductRepository */
        $priceListToProductRepository = $this->doctrineHelper->getEntityRepository(PriceListToProduct::class);

        foreach($filesList as $filename){
            $output->writeln('Début du traitement du fichier '.$filename);
            $codeClient = str_replace([$this->_csvFilesPrefix, '.csv'], '', $filename );
            /** @var Customer $customer */
            $customer = $customerRepository->findOneBy(["mwpCodeClientSage" => $codeClient]);
            if(!$customer or !$customer->getId()) {
                $output->writeln('Aucun customer correspondant au code client : '.$codeClient.'. Traitement du fichier suivant.');
                array_push($unknownsCustomersForCodeClient, $codeClient);
                continue;
            }
            $csvContent = $this->getFileContent($ftpCsvPath, $filename);
            if(!$csvContent) {
                $this->logger->error('Erreur lors du traitement du ficher "'.$filename.'". Fichier potentiellement vide ou corrompu.');
                continue;
            }
            $priceGridAsArray = $this->getCsvContentAsArray($csvContent);

            $priceList = $priceListRepository->getPriceListByCustomer($customer, $defaultWebsite);
            //ici on crée la pricelist si elle n'existe pas et on l'attribue au customer
            if (!$priceList){
                $priceList = $this->createNewPriceList($codeClient);
                if($priceList){
                    $this->addPriceListToCustomer($priceList, $customer, $defaultWebsite);
                }
            }else{
                $productPriceRepository->deleteByPriceList($this->shardManager, $priceList);
            }

            foreach ($priceGridAsArray as $priceGridRow){
                $product = $this->productRepository->findOneBySku($priceGridRow[1]);
                if(!$product){
                    array_push($unknownsSku, $priceGridRow[1]);
                    continue;
                }
                if(array_search($codeClient.'-'.$priceGridRow[1].'-'.$priceGridRow[3], $processedProductPrice)){
                    $this->logger->notice('For '.$priceList->getName().' (Code client: '.$codeClient.') price list, there are several product prices for '.$product->getSku().' product (and quatity :'.$priceGridRow[3].'). Everyone after first one will be ignored.');
                    continue;
                }

                $productPrice = new ProductPrice();
                $price = new Price();
                if(!$this->_productUnits){
                    $this->_productUnits = $this->productUnitRepository->getProductUnits($product);
                }
                $price->setValue(str_replace(',','.', $priceGridRow[2]))->setCurrency('EUR');

                $productPrice
                    ->setProduct($product)
                    ->setPriceRule(null)
                    ->setPrice($price)
                    ->setUnit($this->_productUnits[0])
                    ->setPriceList($priceList)
                    ->setQuantity($priceGridRow[3])
                    ->setVersion(time());

                $this->objectManager->persist($productPrice);

                $priceListToProductRepository->createRelation($priceList, $product);

                array_push($processedProductPrice, $codeClient.'-'.$priceGridRow[1].'-'.$priceGridRow[3]);
            }

            try {
                $this->objectManager->flush();
                $output->writeln('Fichier '.$filename.' traité avec succès.');
            }catch (\Exception $exception){
                $output->writeln('Une erreur est survenu lors de l\'insertion d\'un prix de produit pour la liste de prix '.$codeClient.'.');
                $this->logger->error('Error during '.$codeClient.' products prices insertions. ',
                    [
                        'exception' => $exception,
                        'message' => $exception->getMessage()
                    ]
                );
                $this->checkEntityManagerHealth();
            }

            $filename = $this->renameFile($filename);
            if($this->putFileOnSftpServer($this->getConfigParameterByCode('ftp_import_archives_path'), $filename)){
                $this->deleteLocalFile($filename);
            }
        }
        if(!empty($unknownsCustomersForCodeClient)){
            $this->logger->notice(print_r('No customer corresponding for mwpCodeClientSage : '.json_encode($unknownsCustomersForCodeClient), true));
        }else{
            $this->logger->notice('Toutes les listes de prix présentes sur le serveur ont trouvé le client possédant le code mwpCodeClientSage correspondant.');
        }
        if(!empty($unknownsSku)){
            $this->logger->notice('SKU manquants : '.implode(',', $unknownsSku));
        }else{
            $this->logger->notice('Tous les SKU traité ont été retrouvés dans la base de données ORO.');
        }
    }

    protected function createNewPriceList($codeClient){
        try {
            $priceList = new PriceList();
            $priceList->setName('Grille de prix '. $codeClient)
                ->setPriceListCurrencies(['EUR'])
                ->setActive(true)
            ;
            $this->objectManager->persist($priceList);
            $this->objectManager->flush();
            return $priceList;
        }catch(\Exception $exception){
            $this->logger->error('Error while PriceList creation',
                [
                    'exception' => $exception,
                    'message' => $exception->getMessage()
                ]
            );
            $this->checkEntityManagerHealth();
            return false;
        }
    }

    protected function addPriceListToCustomer($priceList, $customer, $defaultWebsite){
        try {
            $newPriceListToCustomer = new PriceListToCustomer();
            $newPriceListToCustomer->setPriceList($priceList)
                ->setCustomer($customer)
                ->setWebsite($defaultWebsite)
                ->setSortOrder(1)
                ->setMergeAllowed(true);
            $this->objectManager->persist($newPriceListToCustomer);
            $this->objectManager->flush();
            return $newPriceListToCustomer;
        }catch(\Exception $exception){
            $this->logger->error('Error while customer\'s pricelist attribution',
                [
                    'exception' => $exception,
                    'message' => $exception->getMessage()
                ]
            );
            $this->checkEntityManagerHealth();
            return false;
        }
    }

    protected function checkEntityManagerHealth(){
        if (!$this->objectManager->isOpen()) {
            $this->managerRegistry->resetManager();
        }
    }
}