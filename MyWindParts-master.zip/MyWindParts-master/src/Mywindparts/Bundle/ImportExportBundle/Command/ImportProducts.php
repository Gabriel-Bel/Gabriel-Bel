<?php
namespace Mywindparts\Bundle\ImportExportBundle\Command;

use Oro\Bundle\EmailBundle\Mailer\Processor;
use Oro\Bundle\EntityBundle\ORM\DoctrineHelper;
use Oro\Bundle\ImportExportBundle\Async\Topics;
use Oro\Bundle\UserBundle\Entity\User;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\DependencyInjection\ParameterBag\ParameterBagInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\Filesystem\Filesystem;
use Oro\Component\MessageQueue\Client\MessageProducerInterface;
use Oro\Bundle\UserBundle\Entity\UserManager;
use Oro\Bundle\ImportExportBundle\File\FileManager;
use Oro\Bundle\ProductBundle\Entity\Brand;
use Oro\Bundle\ProductBundle\Entity\Repository\BrandRepository;

class ImportProducts extends AbstractCommand
{
    protected static $defaultName = 'mwp:importexport:importproducts';
    protected string $_sftpFilename = 'products.csv';
    protected string $_shippingOptionFile = 'shippingOption.csv';
    protected string $_userEmail = 'sales@mywindparts.com';
    protected bool $_sendLogMail = false;

    protected array $_attibutesToRename = [
        "mwpTypeHuileSelect" => "mwpTypeHuileSelect.name",
        "mwpTypeBatterieSelect" => "mwpTypeBatterieSelect.name",
        "mwpFinitionSelect" => "mwpFinitionSelect.name",
        "mwpTensionSelect" => "mwpTensionSelect.name",
        "brand" => "brand.name",
        "attributeFamily" => "attributeFamily.code",
        "shipping.options.weight.value" => "shipping_options[weight][value]",
        "shipping.options.weight.unit" => "shipping_options[weight][unit]",
        "shipping.options.dimensions.value.length" => "shipping_options[dimensions][value][length]",
        "shipping.options.dimensions.value.width" => "shipping_options[dimensions][value][width]",
        "shipping.options.dimensions.value.height" => "shipping_options[dimensions][value][height]",
        "names.en" => "names.English.value",
        "names.fr" => "names.Français.value",
    ];

    protected array $_productBrands = [];

    private MessageProducerInterface $messageProducer;
    private UserManager $userManager;
    private FileManager $fileManager;

    public function __construct(ParameterBagInterface   $parameterBag,
                                LoggerInterface         $logger,
                                Filesystem              $filesystem,
                                DoctrineHelper          $doctrineHelper,
                                Processor               $mailerProcessor,
                                MessageProducerInterface $messageProducer,
                                UserManager $userManager,
                                FileManager $fileManager)
    {
        parent::__construct($parameterBag, $logger, $filesystem, $doctrineHelper, $mailerProcessor);
        $this->messageProducer = $messageProducer;
        $this->userManager = $userManager;
        $this->fileManager = $fileManager;
    }

    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        $this
            ->setDescription('Import ou mise à jours des produits')
            ->setHelp($this->getDescription())
        ;
        parent::configure();
    }

    public function doExecute(InputInterface $input, OutputInterface $output)
    {

        $importOwner = $this->userManager->findUserByEmail($this->_userEmail);
        if (!$importOwner instanceof User) {
            $this->logger->notice(sprintf('Invalid email. There is no user with %s email!', $this->_userEmail));
            $this->_sendLogMail = true;
            throw new \InvalidArgumentException(sprintf('Invalid email. There is no user with %s email!', $this->_userEmail));
        }


        $output->writeln('Début du traitement du fichier.');
        $localFilePath = $this->getConfigParameterByCode('imports_files_path'). $this->_sftpFilename;
        $csvContent = $this->getFileContent($this->getConfigParameterByCode('ftp_import_products_path'), $this->_sftpFilename);

        //POUR LES TESTS EN LOCAL
        //$csvContent = file_get_contents($localFilePath);
        //

        if($csvContent){

            $backupFilename = $this->renameFile($this->_sftpFilename,null, true);
            if($this->putFileOnSftpServer($this->getConfigParameterByCode('ftp_import_products_archive_path'), $backupFilename)){
                $this->deleteLocalFile($backupFilename);
            }

            //ADD columns and updates from TBD
            $this->updateCsvContent($csvContent, $localFilePath);

            $originFileName = basename($localFilePath);
            $fileName = FileManager::generateUniqueFileName(pathinfo($localFilePath, PATHINFO_EXTENSION));
            $this->fileManager->writeFileToStorage($localFilePath, $fileName);

            $this->messageProducer->send(Topics::PRE_IMPORT, [
                'fileName' => $fileName,
                'userId' => $importOwner->getId(),
                'originFileName' => $originFileName,
                'jobName' =>  'entity_import_from_csv',
                'processorAlias' => 'oro_product_product.add_or_replace',
                'process' => 'import',
                'options' => [ "writer_skip_clear" => "true"],
            ]);
            $this->deleteLocalFile($originFileName);
        }else{
            $this->_sendLogMail = true;
            return false;
        }

        $output->writeln('Fin du traitement du fichier.');
    }

    public function updateCsvContent($csvContent, $filename){

        $nbLine = 1;
        $updatedData = [];
        $headerCsv = [];

        //Remplissage du tableau $this->_productBrands pour faire ensuite un mapping entre BrandName et BrandId
        $this->getAllBrands();
        $handleOrig = fopen($filename, "r");

        while (($data = fgetcsv($handleOrig, 1000, ";")) !== FALSE) {

            $clearData = array_filter($data,
             function ($column) {
                 return ($column !== NULL && $column !== FALSE && $column !== "");
             });

            if(empty($clearData)){
                continue;
            }

            //Mise en place du tableau $headerCsv qui permettra de facilement retrouver une colonne par son nom
            //Sachant que le nombre de colonnes est modifié au cours du process
            if (empty($headerCsv)) {
                $headerCsv = $data;
                //Ajout des colonnes brandId et defaultName qui ne font pas partie de l'import produit apporté par MySolutionConnect
                $headerCsv[] = 'brand.id';
                $headerCsv[] = 'names.default.value';
                $headerIdByName = array_flip($headerCsv);
                continue;
            }

            $updatedData[$nbLine] = $data;

            if (!empty($data[$headerIdByName['brand']])) {
//                $updatedData[$nbLine][$headerIdByName['brand.id']] = array_search(strtoupper($data[$headerIdByName['brand']]), $this->_productBrands);
                $updatedData[$nbLine][$headerIdByName['brand.id']] = is_integer($brandId = array_search(strtoupper($data[$headerIdByName['brand']]), $this->_productBrands))? $brandId : $data[$headerIdByName['brand']];
            }else{
                $updatedData[$nbLine][$headerIdByName['brand.id']] = null;
            }


            //Ajustement TBD//
            //Gestion de l'attributeFamily
            $attributeFamily = explode(", ", $updatedData[$nbLine][$headerIdByName['attributeFamily']]);
            $updatedData[$nbLine][$headerIdByName['attributeFamily']] = end($attributeFamily);

            //Ajout du nom anglais en nom par défaut
            $updatedData[$nbLine][$headerIdByName['names.default.value']] = $updatedData[$nbLine][$headerIdByName['names.en']];
            //Methode pour unset certaines valeurs selon l'attributeFamily
            $updatedData[$nbLine] = $this->updateDataByFamily($updatedData[$nbLine], $headerIdByName);

            //Fin Ajustement TBD//

            $nbLine++;
        }
        fclose($handleOrig);

        //Renommage des valeurs du header avec les noms attendu par Oro
        foreach ($headerCsv as $headerKey => $headerValue){
            if(array_key_exists($headerValue, $this->_attibutesToRename)){
                $headerCsv[$headerKey] = $this->_attibutesToRename[$headerValue];
            }
        }
        array_unshift($updatedData, $headerCsv);

        //generate new csv
        $shippingOptionLines = [];
        $handleNew = fopen($filename, 'w');
        foreach ($updatedData as $rows) {
            $shippingOptionLines[] = [
                $rows[$headerIdByName['sku']],
                $rows[$headerIdByName['primaryUnitPrecision.unit.code']],
                $rows[$headerIdByName['shipping.options.weight.value']],
                $rows[$headerIdByName['shipping.options.weight.unit']],
                $rows[$headerIdByName['shipping.options.dimensions.value.length']],
                $rows[$headerIdByName['shipping.options.dimensions.value.width']],
                $rows[$headerIdByName['shipping.options.dimensions.value.height']]
            ];
            fputcsv($handleNew, $rows);
        }
        fclose($handleNew);


        $this->generateShippingOptionFile($shippingOptionLines);
    }

    private function getAllBrands(){
        /** @var BrandRepository $brandRepository */
        $brandRepository = $this->doctrineHelper->getEntityRepository(Brand::class);
        $productBrands = $brandRepository->findAll();
        /** @var Brand $productBrand */
        foreach ($productBrands as $productBrand){
            $this->_productBrands[$productBrand->getId()] = $productBrand->getDefaultName()->getString();
        }
    }

    private function updateDataByFamily($updatedDataLine, $headerIdByName)
    {
        $productFamily = $updatedDataLine[$headerIdByName['attributeFamily']];

        switch ($productFamily) {
            case 'FiltresHuile':
            case 'FiltresAir':
            case 'BalaisCharbons':
                $updatedDataLine[$headerIdByName['mwpGradeIso']] = null;
                $updatedDataLine[$headerIdByName['mwpGradeNLGI']] = null;
                $updatedDataLine[$headerIdByName['mwpRefFabricant']] = null;
                $updatedDataLine[$headerIdByName['mwpCapacite']] = null;
                break;
            case 'Joints':
            case 'PlaquettesFrein':
            case 'Chiffons':
                $updatedDataLine[$headerIdByName['mwpGradeIso']] = null;
                $updatedDataLine[$headerIdByName['mwpGradeNLGI']] = null;
                $updatedDataLine[$headerIdByName['mwpCapacite']] = null;
                break;
            case 'Graisses':
                $updatedDataLine[$headerIdByName['mwpCapacite']] = null;
                $updatedDataLine[$headerIdByName['mwpGradeIso']] = null;
                $updatedDataLine[$headerIdByName['mwpTypeEolienne']] = null;
                break;
            case 'Huiles':
                $updatedDataLine[$headerIdByName['mwpCapacite']] = null;
                $updatedDataLine[$headerIdByName['mwpGradeNLGI']] = null;
                $updatedDataLine[$headerIdByName['mwpTypeEolienne']] = null;
                break;
            case 'Nettoyants':
            case 'Batteries':
            case 'ColleMastic':
            case 'Peintures':
                $updatedDataLine[$headerIdByName['mwpGradeIso']] = null;
                $updatedDataLine[$headerIdByName['mwpGradeNLGI']] = null;
                $updatedDataLine[$headerIdByName['mwpTypeEolienne']] = null;
                $updatedDataLine[$headerIdByName['mwpCapacite']] = null;
        }
        return $updatedDataLine;
    }

    protected function generateShippingOptionFile($shippingOptionLines)
    {
        if(!empty($shippingOptionLines)) {
            $shippingOptionFilename = $this->getConfigParameterByCode('imports_files_path'). $this->_shippingOptionFile;
            $handleShipping = fopen($shippingOptionFilename, 'w');
            foreach ($shippingOptionLines as $shippingOptionLine) {
                fputcsv($handleShipping, $shippingOptionLine);
            }
            fclose($handleShipping);
        }
    }
}