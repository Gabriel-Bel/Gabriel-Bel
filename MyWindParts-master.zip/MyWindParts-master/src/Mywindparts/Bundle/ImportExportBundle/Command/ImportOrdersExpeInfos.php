<?php

namespace Mywindparts\Bundle\ImportExportBundle\Command;

use Doctrine\Persistence\ManagerRegistry;
use Doctrine\Persistence\ObjectManager;
use Oro\Bundle\EntityExtendBundle\Entity\AbstractEnumValue;
use Oro\Bundle\EntityExtendBundle\Tools\ExtendHelper;
use Oro\Bundle\OrderBundle\Entity\Repository\OrderRepository;
use Oro\Bundle\OrderBundle\Entity\Order;
use Oro\Bundle\EmailBundle\Mailer\Processor;
use Oro\Bundle\EntityBundle\ORM\DoctrineHelper;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\DependencyInjection\ParameterBag\ParameterBagInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\Filesystem\Filesystem;
use Oro\Bundle\OrderBundle\Entity\OrderShippingTracking;
use Oro\Bundle\AttachmentBundle\Entity\Attachment;
use Oro\Bundle\AttachmentBundle\Entity\File;
use Symfony\Component\HttpFoundation\File\File as SymfonyFile;
use Oro\Bundle\UserBundle\Entity\User;
use Oro\Bundle\UserBundle\Entity\Repository\UserRepository;

class ImportOrdersExpeInfos extends AbstractCommand
{
    /**
     * Admin User who's gonna ba attached to new files
     * @var User
     */
    protected $_adminUser;
    /**
     * Order to modify
     * @var Order
     */
    protected $_order;
    /**
     * Shipped Internal Status Code Object
     * @var AbstractEnumValue
     */
    protected $_shippedInternalStatusCode;
    protected static $defaultName = 'mwp:importexport:importordersexpeinfos';
    protected string $_blFilesPrefix = 'MWP-BL-';
    protected int $_currentOrderId = 0;
    protected int $_adminUserId = 1;
    protected bool $_sendLogMail = false;
    private ObjectManager $objectManager;
    private ManagerRegistry $managerRegistry;

    public function __construct(ParameterBagInterface $parameterBag,
                                LoggerInterface       $logger,
                                Filesystem            $filesystem,
                                DoctrineHelper        $doctrineHelper,
                                Processor             $mailerProcessor,
                                ObjectManager         $objectManager,
                                ManagerRegistry       $managerRegistry)
    {
        parent::__construct($parameterBag, $logger, $filesystem, $doctrineHelper, $mailerProcessor);
        $this->objectManager = $objectManager;
        $this->managerRegistry = $managerRegistry;
    }

    public function configure()
    {
        $this
            ->setDescription('Import Order Expeditions Informations from Sage')
            ->setHelp($this->getDescription());
        parent::configure();
    }

    public function doExecute(InputInterface $input, OutputInterface $output)
    {
        $ftpFilePath = $this->getConfigParameterByCode('ftp_import_expe_path');
        $localFilesPath = $this->getConfigParameterByCode('imports_files_path');
        $filesList = $this->getFilesList($ftpFilePath, $this->_blFilesPrefix);

        /** @var UserRepository $userRepository */
        $userRepository = $this->doctrineHelper->getEntityRepository(User::class);
        $this->_adminUser = $userRepository->findOneBy(['id' => $this->_adminUserId]);

        $this->_shippedInternalStatusCode = $this->objectManager->getRepository(ExtendHelper::buildEnumValueClassName(Order::INTERNAL_STATUS_CODE))->findOneBy(['id' => 'shipped']);

        foreach ($filesList as $filename) {
            $output->writeln('Début du traitement du fichier ' . $filename);

            //Update $_currentOrderId and $_order
            $this->updateCurrentOrder($filename);

            if (strpos($filename, '.csv')) { //CSV void
                $fileCsvContent = $this->getFileContent($ftpFilePath, $filename);
                if ($fileCsvContent && $csvExpeInfos = $this->getCsvContentAsArray($fileCsvContent, false)) {
                    foreach ($csvExpeInfos as $csvExpeInfo) {
                        if ($csvExpeInfo[0] != $this->_currentOrderId) {
                            $this->logger->info('An order number indicated on this file is different to the order number indicated in the filename. Please verify data on order number :' . $this->_currentOrderId, [$filename]);
                            $this->_sendLogMail = true;
                        }
                        $trackingMethod = $csvExpeInfo[1];
                        $trackingNumber = $csvExpeInfo[2];
                        if ($this->createShippingTracking($this->_order, $trackingMethod, $trackingNumber)) {
                            $output->writeln('Fichier ' . $filename . ' traité avec succès.');
                            if ($this->putFileOnSftpServer($this->getConfigParameterByCode('ftp_import_expe_archive_path'), $filename)) {
                                $this->deleteLocalFile($filename);
                            }
                        }
                    }
                }
            } elseif (strpos($filename, '.pdf')) { //PDF void
                $filePdfContent = $this->getFileContent($ftpFilePath, $filename);
                if ($filePdfContent && $this->createNewAttachmentFile($this->_order, $localFilesPath . $filename)) {
                    $output->writeln('Fichier ' . $filename . ' traité avec succès.');
                    if ($this->putFileOnSftpServer($this->getConfigParameterByCode('ftp_import_expe_archive_path'), $filename)) {
                        $this->deleteLocalFile($filename);
                    }
                }
            } else {
                $this->logger->info('The file extension is different than csv or pdf, please delete this file from FTP server :', [$filename]);
            }
        }
    }

    protected function updateCurrentOrder($filename)
    {
        $orderId = str_replace([$this->_blFilesPrefix, '.pdf', '.csv'], '', $filename);
        if ($orderId != $this->_currentOrderId) {
            $this->_currentOrderId = $orderId;

            /** @var OrderRepository $orderRepository */
            $orderRepository = $this->doctrineHelper->getEntityRepository(Order::class);
            $this->_order = $orderRepository->findOneBy(["id" => $this->_currentOrderId]);
        }
    }

    protected function createShippingTracking($order, $trackingMethod, $trackingNumber)
    {
        try {
            $shippingTracking = new OrderShippingTracking();
            $shippingTracking->setMethod($trackingMethod)
                ->setNumber($trackingNumber)
                ->setOrder($order);
            $this->objectManager->persist($shippingTracking);
            $order->setInternalStatus($this->_shippedInternalStatusCode);
            $this->objectManager->persist($order);
            $this->objectManager->flush();
            return true;
        } catch (\Exception $exception) {
            $this->_sendLogMail = true;
            if (!$this->objectManager->isOpen()) {
                $this->managerRegistry->resetManager();
            }
            $this->logger->error('Error while Shipping Tracking creation',
                [
                    'exception' => $exception,
                    'message' => $exception->getMessage()
                ]
            );
            return false;
        }
    }

    protected function createNewAttachmentFile($order, $files)
    {
        try {
            $newFile = new File();
            $attachmentEntity = new Attachment();
            $symfonyFile = new SymfonyFile($files);

            $newFile
                ->setOriginalFilename($symfonyFile->getFilename())
                ->setOwner($this->_adminUser)
                ->setParentEntityClass(Attachment::class)
                ->setParentEntityFieldName('file')
                ->setParentEntityId($attachmentEntity->getId())
                ->setFile($symfonyFile);
            $attachmentEntity
                ->setFile($newFile)
                ->setComment('Bon de livraison pour la commande' . $order->getId())
                ->setOrganization($this->_adminUser->getOrganization())
                ->setTarget($order)
                ->setOwner($this->_adminUser);

            $this->objectManager->persist($attachmentEntity);
            $this->objectManager->persist($newFile);
            $this->objectManager->flush();
            return true;
        } catch (\Exception $exception) {
            $this->_sendLogMail = true;
            if (!$this->objectManager->isOpen()) {
                $this->managerRegistry->resetManager();
            }
            $this->logger->error('Error while Attachment file creation',
                [
                    'exception' => $exception,
                    'message' => $exception->getMessage()
                ]
            );
            return false;
        }
    }
}