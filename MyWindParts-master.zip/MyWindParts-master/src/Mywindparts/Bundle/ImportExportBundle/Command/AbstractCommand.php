<?php

namespace Mywindparts\Bundle\ImportExportBundle\Command;

use Oro\Bundle\AttachmentBundle\Entity\File;
use Oro\Bundle\EmailBundle\Entity\EmailAttachmentContent;
use Oro\Bundle\EntityBundle\ORM\DoctrineHelper;
use Psr\Log\LoggerInterface;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\DependencyInjection\ParameterBag\ParameterBagInterface;
use Oro\Bundle\EmailBundle\Form\Model\Email;
use Oro\Bundle\EmailBundle\Form\Model\EmailAttachment;
use Oro\Bundle\EmailBundle\Entity\EmailAttachment as EmailAttachmentEntity;
use Oro\Bundle\EmailBundle\Mailer\Processor;
use Symfony\Component\HttpFoundation\File\File as ComponentFile;
use phpseclib\Net\SFTP;
use Symfony\Component\Filesystem\Filesystem;

abstract class AbstractCommand extends Command
{
    /**
     * SFTP Connection
     * @var SFTP
     */
    protected $_sftpConnection;
    protected bool $_sendLogMail = true;
    protected ParameterBagInterface $parameterBag;
    protected Filesystem $filesystem;
    protected Processor $mailerProcessor;
    protected LoggerInterface $logger;
    protected DoctrineHelper $doctrineHelper;

    public function __construct(ParameterBagInterface $parameterBag,
                                LoggerInterface $logger,
                                Filesystem $filesystem,
                                DoctrineHelper $doctrineHelper,
                                Processor $mailerProcessor
    )
    {
        parent::__construct();
        $this->parameterBag = $parameterBag;
        $this->mailerProcessor = $mailerProcessor;
        $this->filesystem = $filesystem;
        $this->logger = $logger;
        $this->doctrineHelper = $doctrineHelper;
    }

    abstract public function doExecute(InputInterface $input, OutputInterface $output);

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $output->writeln("Starting ".$this->getName());
        $this->doExecute($input, $output);
        if($this->_sendLogMail){
            $loggerFilename = $this->prepareLoggerFile();
            if ($loggerFilename){
                $body = 'Fichier de log généré par le script '.$this->getName().' du ' .date('Y-m-d-H').'H';
                $this->sendMail($this->getName()." results", $body, $loggerFilename['dirname']."/".$loggerFilename['basename']);
                $this->filesystem->copy($loggerFilename['dirname'] . "/" . $loggerFilename['basename'],
                                        $loggerFilename['dirname']."/import_export/".date("Y-m-d")."/".$loggerFilename['basename']);
                $this->deleteLocalFile($loggerFilename['basename'], $loggerFilename['dirname'].'/');
            }
        }
        $output->writeln($this->getName()." has correctly finish.");
    }

    protected function getFileContent($path, $filename){
        $fileDirectory = $this->getConfigParameterByCode('imports_files_path');
        if(!$this->_sftpConnection){
            $this->openSftpConnection();
        }

        if($this->getFileFromSftp($path, $filename, $fileDirectory.$filename)){
            try {
                $file = file_get_contents($fileDirectory.$filename);
                if($file){
                    $this->_sftpConnection->delete($path.$filename); //Supprime le fichier en distant, à commenter pour les tests
                }
            }catch (\Exception $exception){
                $this->logger->error( 'No file was found.', ['exception' => $exception, 'message' => $exception->getMessage()]);
                return false;
            }
        }else{
            $this->logger->error( 'No file was found.');
            return false;
        }

        $this->closeSftpConnection();
        return $file;
    }

    protected function getCsvContentAsArray($csvContent, $csvWithHeaderLine = true){
        $lines = explode("\r\n", $csvContent);
        $csvArray = [];
        foreach ($lines as $lineKey => $line) {
            $dataLine = explode(";", $line);
            $csvArray[$lineKey] = $dataLine;
        }
        if($csvWithHeaderLine){
            array_shift($csvArray);
        }
        return $csvArray;
    }

    protected function getConfigParameterByCode($paramCode){
        return $this->parameterBag->get($paramCode);
    }

    protected function deleteLocalFile($filename, $filepath = null){
        try {
            if(is_null($filepath)){
                $filepath = $this->getConfigParameterByCode('imports_files_path');
            }
            if($this->filesystem->exists($filepath.$filename)){
                $this->filesystem->remove($filepath.$filename);
            }
        }catch(\Exception $exception){
            $this->logger->error('Error while trying to delete local file.', ['exception' => $exception, 'message' => $exception->getMessage()]);
        }
    }

    protected function openSftpConnection(){
        try {
            $this->_sftpConnection = new SFTP($this->getConfigParameterByCode('ftp_ip_address'));
            $this->_sftpConnection->login(
                $this->getConfigParameterByCode('ftp_user'),
                $this->getConfigParameterByCode('ftp_password')
            );
        }catch(\Exception $exception){
            $this->logger->error('Error while trying to connected to SFTP server', ['exception' => $exception, 'message' => $exception->getMessage()]);
        }
        return false;
    }

    protected function getFilesList( $dir = '.', $patern = false){
        if(!$this->_sftpConnection){
            $this->openSftpConnection();
        }
        $filesList = $this->_sftpConnection->nlist($dir);
        if ($patern){
            foreach($filesList as $fileKey => $fileName){
                if(!is_numeric(strpos($fileName, $patern))){
                    unset($filesList[$fileKey]);
                }
            }

        }
        return $filesList;
    }

    protected function getFileFromSftp($path, $filename, $localFile){
        /** @var \phpseclib\Net\SFTP $_sftpConnection */

        $this->_sftpConnection->chdir($path);
        if($this->_sftpConnection->file_exists($filename)){
            return $this->_sftpConnection->get($filename, $localFile);
        }
        return false;
    }

    protected function putFileOnSftpServer($path, $filename){
        $csvDirectory = $this->getConfigParameterByCode('imports_files_path');
        /** @var \phpseclib\Net\SFTP $_sftpConnection */
        if(!$this->_sftpConnection){
            $this->openSftpConnection();
        }
        try {
            $this->_sftpConnection->chdir($path);
            $this->_sftpConnection->put($filename, $csvDirectory.$filename, SFTP::SOURCE_LOCAL_FILE);
            $this->closeSftpConnection();
            return true;
        }catch(\Exception $exception){
            $this->logger->error('Error while uploading archive file on SFTP server', ['exception' => $exception,'message' => $exception->getMessage()]);
        }
        return false;
    }

    protected function closeSftpConnection(){
        /** @var \phpseclib\Net\SFTP $_sftpConnection */
        $this->_sftpConnection->disconnect();
        $this->_sftpConnection = false;
        return $this->_sftpConnection;
    }

    protected function renameFile($filename, $filepath = null, $copyForBackup = false){
        try {
            if(is_null($filepath)){
                $filepath = $this->getConfigParameterByCode('imports_files_path');
            }
            $fileInfo = pathinfo($filepath.$filename);
            $newFilename = substr_replace($filename, date('-Y-m-d-H'), strpos($filename, '.'.$fileInfo['extension']),0);
            if($copyForBackup){
                $this->filesystem->copy($filepath.$filename, $filepath.$newFilename, true);
            }else{
                $this->filesystem->rename($filepath.$filename, $filepath.$newFilename, true);
            }
            return $newFilename;
        }catch(\Exception $exception){
            $this->logger->error('Error while trying to rename file.', ['exception' => $exception,'message' => $exception->getMessage()]);
            return false;
        }
    }

    protected function sendMail($subject, $body, $file){

        $email = new Email();
        $email->setFrom($this->getConfigParameterByCode('import_script_from_email'));
        $email->setTo($this->getConfigParameterByCode('import_script_to_email'));
        $email->setSubject($subject);
        $email->setBody($body);

        $componentFile = new ComponentFile($file);
        $attachmentFile = new File();
        $attachmentFile->setFile($componentFile);
        $attachmentFile->setFilename($componentFile->getFilename());
        $attachmentFile->setFileSize($componentFile->getSize());
        $attachmentFile->setMimeType($componentFile->getMimeType());
        $attachmentFile->setExtension($componentFile->getExtension());

        $emailAttachementContent = new EmailAttachmentContent();
        $emailAttachementContent->setContent(file_get_contents($file));

        $emailAttachementEntity = new EmailAttachmentEntity();
        $emailAttachementEntity
            ->setFile($attachmentFile)
            ->setFileName($attachmentFile->getFilename())
            ->setContentType($componentFile->getMimeType())
            ->setContent($emailAttachementContent)
        ;

        $emailAttachement = new EmailAttachment();
        $emailAttachement->setEmailAttachment($emailAttachementEntity);
        $emailAttachement->setMimeType($attachmentFile->getMimeType());
        $emailAttachement->setFileSize($attachmentFile->getFileSize());
        $emailAttachement->setType(EmailAttachment::TYPE_EMAIL_ATTACHMENT);

        $email->setAttachments([$emailAttachement]);

        try {
            $this->mailerProcessor->process($email, null, false);
        }catch (\Exception $exception){
            $this->logger->error('Error while trying to send email.', ['exception' => $exception,'message' => $exception->getMessage()]);
        }
        return true;
    }

    protected function prepareLoggerFile(){
        foreach ($this->logger->getHandlers() as $handler){
            if ($handler instanceof \Monolog\Handler\StreamHandler){
                $url = $handler->getUrl();
                $pathInfoUrl = pathinfo($url);
                $this->deleteLocalFile($url, $pathInfoUrl['dirname'].'/');
                $pathInfoUrl['basename'] = $this->renameFile($pathInfoUrl['basename'], $pathInfoUrl['dirname'].'/');
                return $pathInfoUrl;
            }
        }
        return false;
    }
}