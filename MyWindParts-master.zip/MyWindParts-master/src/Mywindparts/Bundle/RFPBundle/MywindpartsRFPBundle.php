<?php

namespace Mywindparts\Bundle\RFPBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MywindpartsRFPBundle extends Bundle
{
}

