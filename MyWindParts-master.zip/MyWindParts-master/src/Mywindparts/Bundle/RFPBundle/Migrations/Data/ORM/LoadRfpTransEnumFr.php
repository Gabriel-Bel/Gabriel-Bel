<?php
namespace Mywindparts\Bundle\RFPBundle\Migrations\Data\ORM;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Persistence\ObjectManager;
use Oro\Bundle\EntityExtendBundle\Entity\EnumValueTranslation;
use Oro\Bundle\EntityExtendBundle\Tools\ExtendHelper;
use Oro\Bundle\RFPBundle\Entity\Request;

class LoadRfpTransEnumFr extends AbstractFixture
{
    public function load(ObjectManager $em)
    {
        $className = ExtendHelper::buildEnumValueClassName(Request::CUSTOMER_STATUS_CODE);

        $statusTranslation = [
            'pending_approval' => 'Validation en attente',
            'cancelled' => 'Annulée',
            'requires_attention' => 'Nécessite une attention particulière',
            'submitted' => 'Envoyée',
        ];

        foreach ($statusTranslation as $statusKey=>$statusLabel) {
            $enumValueTranslation = new  EnumValueTranslation();
            $enumValueTranslation
                ->setForeignKey($statusKey)
                ->setContent($statusLabel)
                ->setLocale('fr_FR')
                ->setObjectClass($className)
                ->setField('name');

            $em->persist($enumValueTranslation);
        }
        $em->flush();
    }
}